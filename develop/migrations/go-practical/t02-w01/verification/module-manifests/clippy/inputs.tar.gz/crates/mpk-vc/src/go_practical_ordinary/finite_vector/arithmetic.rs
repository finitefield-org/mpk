//! Universal address bounds and cancellation, using the existing Nat laws.
use super::*;

fn commute(a: Expr, b: Expr) -> Equality {
    Equality::natural(
        add(a.clone(), b.clone()),
        add(b.clone(), a.clone()),
        nc("AddComm", vec![a, b]),
    )
}
fn associate(a: Expr, b: Expr, c: Expr) -> Equality {
    Equality::natural(
        add(add(a.clone(), b.clone()), c.clone()),
        add(a.clone(), add(b.clone(), c.clone())),
        nc("AddAssoc", vec![a, b, c]),
    )
}
fn add_zero(a: Expr) -> Equality {
    Equality::natural(add(a.clone(), zero()), a.clone(), nc("AddZero", vec![a]))
}
fn less_left(e: Equality, right: Expr) -> Equality {
    e.clone().mapped(
        lam("_value", nat(), less(var("_value"), right.clone())),
        less(e.left, right.clone()),
        less(e.right, right),
        boolean(),
    )
}
fn less_right(left: Expr, e: Equality) -> Equality {
    e.clone().mapped(
        lam("_value", nat(), less(left.clone(), var("_value"))),
        less(left.clone(), e.left),
        less(left, e.right),
        boolean(),
    )
}
pub(super) fn unshift(half: Expr, small: Expr) -> Result<Equality> {
    let from = sub(add(half.clone(), small.clone()), half.clone());
    let middle = sub(add(small.clone(), half.clone()), half.clone());
    commute(half.clone(), small.clone())
        .mapped(
            lam("_value", nat(), sub(var("_value"), half.clone())),
            from,
            middle.clone(),
            nat(),
        )
        .then(Equality::natural(
            middle,
            small.clone(),
            nc("SubAddRight", vec![small, half]),
        ))
}
pub(super) fn not_below(half: Expr, small: Expr) -> Result<Equality> {
    let zero_plus = commute(zero(), half.clone()).then(add_zero(half.clone()))?;
    less_left(commute(half.clone(), small.clone()), half.clone())
        .then(less_right(
            add(small.clone(), half.clone()),
            zero_plus.reverse(),
        ))?
        .then(Equality::boolean(
            less(add(small.clone(), half.clone()), add(zero(), half.clone())),
            less(small.clone(), zero()),
            nc("LessTranslate", vec![small.clone(), zero(), half]),
        ))?
        .then(Equality::boolean(
            less(small.clone(), zero()),
            bit(false),
            nc("LessZero", vec![small]),
        ))
}

pub(super) fn bounds(vectors: &mut Vectors<'_>, d: usize) -> Result<()> {
    let (address, padding) = (bits(d), var("padding"));
    let property = |address: &[Expr]| inside(index(d, address), add(capacity(d), padding.clone()));
    let proof = if d == 0 {
        let successor = commute(one(), padding.clone())
            .then(Equality::natural(
                add(padding.clone(), one()),
                succ(add(padding.clone(), zero())),
                nc("AddSucc", vec![padding.clone(), zero()]),
            ))?
            .then(add_zero(padding.clone()).on_succ())?;
        less_right(zero(), successor)
            .then(Equality::boolean(
                less(zero(), succ(padding.clone())),
                bit(true),
                nc("LessZeroSucc", vec![padding.clone()]),
            ))?
            .proof
    } else {
        let (half, small) = (capacity(d - 1), index(d - 1, &address[1..]));
        let explicit = index_body(d, &address);
        let index_change = definition(
            d,
            "Index",
            address.clone(),
            nat(),
            index(d, &address),
            explicit.clone(),
        )
        .mapped(
            lam(
                "_index",
                nat(),
                less(var("_index"), add(capacity(d), padding.clone())),
            ),
            less(index(d, &address), add(capacity(d), padding.clone())),
            less(explicit.clone(), add(capacity(d), padding.clone())),
            boolean(),
        );
        let capacity_change =
            definition(d, "Capacity", vec![], nat(), capacity(d), capacity_body(d)).mapped(
                lam(
                    "_capacity",
                    nat(),
                    less(explicit.clone(), add(var("_capacity"), padding.clone())),
                ),
                less(explicit.clone(), add(capacity(d), padding.clone())),
                less(explicit.clone(), add(capacity_body(d), padding.clone())),
                boolean(),
            );
        let previous = |padding: Expr| {
            let mut args = address[1..].to_vec();
            args.push(padding);
            fc(d - 1, "IndexPaddedBound", args)
        };
        let step = Equality::boolean(
            less(explicit, add(capacity_body(d), padding.clone())),
            bit(true),
            gc(
                "IndexPaddedStep",
                vec![
                    half.clone(),
                    small,
                    address[0].clone(),
                    padding.clone(),
                    previous(add(half, padding.clone())),
                    previous(padding.clone()),
                ],
            ),
        );
        index_change.then(capacity_change)?.then(step)?.proof
    };
    let mut args = bit_args(d);
    args.push(("padding", nat()));
    vectors.emit(
        d,
        "IndexPaddedBound",
        &args,
        property(&address),
        proof,
        true,
    )?;
    let mut padded = address.clone();
    padded.push(zero());
    let proof = less_right(index(d, &address), add_zero(capacity(d)))
        .reverse()
        .then(Equality::boolean(
            less(index(d, &address), add(capacity(d), zero())),
            bit(true),
            fc(d, "IndexPaddedBound", padded),
        ))?
        .proof;
    vectors.emit(
        d,
        "IndexBound",
        &bit_args(d),
        inside(index(d, &address), capacity(d)),
        proof,
        true,
    )
}

pub(super) fn padded_step(builder: &mut Builder) -> Result<()> {
    let (half, small, head, padding) = (var("half"), var("small"), var("head"), var("padding"));
    let no = less_right(
        small.clone(),
        associate(half.clone(), half.clone(), padding.clone()),
    )
    .then(Equality::boolean(
        less(
            small.clone(),
            add(half.clone(), add(half.clone(), padding.clone())),
        ),
        bit(true),
        var("low"),
    ))?
    .proof;
    let yes = less_left(
        commute(half.clone(), small.clone()),
        add(add(half.clone(), half.clone()), padding.clone()),
    )
    .then(less_right(
        add(small.clone(), half.clone()),
        associate(half.clone(), half.clone(), padding.clone()),
    ))?
    .then(less_right(
        add(small.clone(), half.clone()),
        commute(half.clone(), add(half.clone(), padding.clone())),
    ))?
    .then(Equality::boolean(
        less(
            add(small.clone(), half.clone()),
            add(add(half.clone(), padding.clone()), half.clone()),
        ),
        less(small.clone(), add(half.clone(), padding.clone())),
        nc(
            "LessTranslate",
            vec![
                small.clone(),
                add(half.clone(), padding.clone()),
                half.clone(),
            ],
        ),
    ))?
    .then(Equality::boolean(
        less(small.clone(), add(half.clone(), padding.clone())),
        bit(true),
        var("high"),
    ))?
    .proof;
    let property = |head| {
        inside(
            choose(nat(), head, add(half.clone(), small.clone()), small.clone()),
            add(add(half.clone(), half.clone()), padding.clone()),
        )
    };
    emit(
        builder,
        "Mpk.Go.Practical.FiniteVector.IndexPaddedStep",
        &[
            ("half", nat()),
            ("small", nat()),
            ("head", boolean()),
            ("padding", nat()),
            (
                "low",
                inside(
                    small.clone(),
                    add(half.clone(), add(half.clone(), padding.clone())),
                ),
            ),
            (
                "high",
                inside(small.clone(), add(half.clone(), padding.clone())),
            ),
        ],
        property(head.clone()),
        call(
            "Std.Bool.cases",
            vec![
                lam("_head", boolean(), property(var("_head"))),
                no,
                yes,
                head,
            ],
        ),
        true,
    )
}
