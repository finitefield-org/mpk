use mpk_vc::go_practical_ordinary::*;
use mpk_vc::go_practical_type_keys::*;
use serde_json::{json, Value};
use std::io::Write;
use std::path::{Path, PathBuf};

fn corpus(name: &str) -> Value {
    let root = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../develop/migrations/go-practical/t02-w01/verification");
    serde_json::from_slice(&std::fs::read(root.join(name).join("corpus.json")).unwrap()).unwrap()
}
fn error_corpus(name: &str) -> Value {
    if name == "heterogeneous-payloads" {
        let path=Path::new(env!("CARGO_MANIFEST_DIR")).join("../../develop/migrations/go-practical/t02-w01/verification/source-error-representation/corpus-heterogeneous.json");
        serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap()
    } else {
        corpus("error-dispatch")
    }
}
fn unhex(value: &Value) -> Vec<u8> {
    value
        .as_str()
        .unwrap()
        .as_bytes()
        .chunks_exact(2)
        .map(|p| u8::from_str_radix(std::str::from_utf8(p).unwrap(), 16).unwrap())
        .collect()
}
fn keys(corpus: &Value) -> GoTypeKeyComponents {
    let input = &corpus["input"];
    let sources = input["sources"]
        .as_array()
        .unwrap()
        .iter()
        .map(|s| {
            GoTypeSourceBuffer::import(
                &serde_json::to_vec(&s["object"]).unwrap(),
                &unhex(&s["raw_hex"]),
            )
            .unwrap()
        })
        .collect::<Vec<_>>();
    import_go_type_key_components(&unhex(&input["components_hex"]), &sources).unwrap()
}
fn locate(keys: &GoTypeKeyComponents, row: &Value, kind: &str) -> GoSourceSelectionRef {
    let source = row["source"].as_str().unwrap();
    let parsed = keys.source_declarations().source(source).unwrap();
    let node = parsed
        .nodes()
        .iter()
        .position(|n| {
            n.kind() == kind
                && n.start() == row["start"].as_u64().unwrap() as usize
                && n.end() == row["end"].as_u64().unwrap() as usize
        })
        .unwrap();
    GoSourceSelectionRef::new(source, node)
}
fn dispatch(name: &str) -> GoSourceErrorSelection {
    let c = error_corpus(name);
    let keys = keys(&c);
    let row = c["cases"]
        .as_array()
        .unwrap()
        .iter()
        .find(|r| r["input"]["name"] == name)
        .unwrap();
    let input = &row["input"];
    let cases = input["entry_cases"]
        .as_array()
        .map(|cs| {
            cs.iter()
                .map(|n| {
                    locate(
                        &keys,
                        &c["declarations"][format!("example.com/policy.{}", n.as_str().unwrap())],
                        "TypeSpec",
                    )
                })
                .collect::<Vec<_>>()
        })
        .unwrap_or_default();
    let mut roots = vec![];
    let mut entries = vec![];
    for row in input["roots"].as_array().unwrap() {
        let r = locate(&keys, &row["ref"], "FuncDecl");
        let name = row["name"].as_str().unwrap();
        roots.push(r.clone());
        if matches!(
            name,
            "Entry" | "Expr" | "Paren" | "Guarded" | "Branch" | "Imported" | "OtherRoot"
        ) {
            entries.push(GoErrorEntryConstraint::new(
                r.clone(),
                0,
                vec![],
                if name == "OtherRoot" {
                    vec![]
                } else {
                    cases.clone()
                },
            ));
        }
        if name == "Nested" {
            entries.push(GoErrorEntryConstraint::new(
                r.clone(),
                0,
                vec![GoErrorEntryStep::Field(0)],
                cases.clone(),
            ));
            entries.push(GoErrorEntryConstraint::new(
                r,
                0,
                vec![GoErrorEntryStep::Field(1), GoErrorEntryStep::Elements],
                vec![],
            ));
        }
    }
    derive_go_source_error_selection(&keys, &roots, &entries).unwrap()
}
fn write(root: &Path, name: &str, raw: &[u8]) {
    std::fs::create_dir_all(root).unwrap();
    std::fs::OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(root.join(name))
        .unwrap()
        .write_all(raw)
        .unwrap();
}
#[path = "support/go_word_division_dependencies.rs"]
mod dependencies;

fn check(name: &str) {
    let selection = dispatch(name);
    let domain = selection.domain();
    let catalogue = generate_go_practical_source_value_relation_catalogue(domain).unwrap();
    assert_eq!(
        catalogue
            .case_tags()
            .iter()
            .map(|(id, _)| id.as_str())
            .collect::<Vec<_>>(),
        domain
            .error_cases()
            .iter()
            .map(|c| c.value_type_id())
            .collect::<Vec<_>>()
    );
    assert_eq!(
        catalogue
            .source_types()
            .iter()
            .map(|k| k.id())
            .collect::<Vec<_>>(),
        domain.types().map(|k| k.id()).collect::<Vec<_>>()
    );
    let prior =
        mpk_cert::decode_canonical_certificate(catalogue.prior_operations_certificate_bytes())
            .unwrap();
    let before = dependencies::declarations(&prior);
    let out = std::env::var_os("MPK_GO_SOURCE_VALUE_RELATIONS_OUTPUT").map(PathBuf::from);
    for boxed in std::iter::once(None).chain(
        catalogue
            .case_tags()
            .iter()
            .map(|(id, _)| Some(id.as_str())),
    ) {
        let row = catalogue.generate_row(boxed).unwrap();
        let decoded = mpk_cert::decode_canonical_certificate(row.certificate_bytes()).unwrap();
        let after = dependencies::declarations(&decoded);
        for (n, v) in &before {
            if n.starts_with(&(row.source_layout_module_name().to_string() + ".")) {
                assert_eq!(
                    after.get(n),
                    Some(v),
                    "all prior source-specific type/body/proof identities remain {n}"
                );
            }
        }
        assert!(decoded.imports.is_empty());
        assert_eq!(decoded.axiom_report.summary.total_axiom_count, 0);
        assert_eq!(
            catalogue
                .import_row(row.certificate_bytes(), boxed)
                .unwrap(),
            row
        );
        if let Some(other) = catalogue
            .case_tags()
            .iter()
            .map(|(id, _)| Some(id.as_str()))
            .find(|v| *v != boxed)
        {
            assert_eq!(
                catalogue.import_row(row.certificate_bytes(), other),
                Err(GoOrdinaryError::Linkage)
            );
        }
        let file = format!("{name}-{}", boxed.unwrap_or("nil"));
        if let Some(root) = &out {
            write(root, &format!("{file}.mpcert"), row.certificate_bytes());
            write(root,&format!("{file}.sources.json"),&serde_json::to_vec_pretty(&json!({"unit":name,"module":row.module_name(),"relation_module":row.relation_module_name(),"source_layout_module":row.source_layout_module_name(),"boxing_module":row.boxing_module_name(),"operations_module":row.operations_module_name(),"source_error_type_id":row.source_error_type_id(),"boxed_source_type_id":row.boxed_source_type_id(),"case_tags":row.case_tags(),"types":catalogue.source_types(),"underlying":catalogue.source_types().iter().filter_map(|t|catalogue.underlying_type_id(t.id()).map(|u|json!([t.id(),u]))).collect::<Vec<_>>(),"all_prior_source_operations_specific_identities_unchanged":true,"declarations":decoded.declarations.len(),"terms":decoded.term_table.len(),"bytes":row.certificate_bytes().len(),"full_encoding_relation_not_Go_comparison_or_validity":true})).unwrap());
        }
        let start = std::time::Instant::now();
        let result = mpk_kernel::verify_certificate_bytes_json_output(row.certificate_bytes());
        println!("{file}: {:?}", start.elapsed());
        if let Some(root) = &out {
            write(
                root,
                &format!("{file}.rust.json"),
                format!("{}\n", result.json).as_bytes(),
            );
        }
        assert!(result.accepted, "{file}: {}", result.json);
    }
}
#[test]
fn closed_source_relations_empty_and_small_all_fields() {
    for name in ["nil-only", "entry"] {
        check(name);
    }
}
#[test]
fn closed_source_relations_heterogeneous_full_payloads() {
    check("heterogeneous-payloads");
}
#[test]
fn all_seventy_closed_source_relations_keep_full_u() {
    check("seventy-cases");
}

#[test]
fn unary_fix_keeps_complete_large_and_heterogeneous_source_rows() {
    use sha2::{Digest, Sha256};
    let prior = std::env::var_os("MPK_GO_SOURCE_VALUE_RELATIONS_REPLAY_ROOT")
        .map(PathBuf::from)
        .unwrap_or_else(|| {
            Path::new(env!("CARGO_MANIFEST_DIR")).join(
                "../../develop/migrations/go-practical/t02-w01/verification/source-value-relations",
            )
        });
    let mut rows = vec![];
    for (name, epoch) in [
        ("seventy-cases", "final-large"),
        ("heterogeneous-payloads", "heterogeneous-final"),
    ] {
        let selected = dispatch(name);
        let catalogue =
            generate_go_practical_source_value_relation_catalogue(selected.domain()).unwrap();
        let last = &catalogue.case_tags().last().unwrap().0;
        for boxed in [None, Some(last.as_str())] {
            let file = prior
                .join(epoch)
                .join("certificates")
                .join(format!("{name}-{}.mpcert", boxed.unwrap_or("nil")));
            let original = std::fs::read(&file).unwrap();
            let report: Value =
                serde_json::from_slice(&std::fs::read(file.with_extension("rust.json")).unwrap())
                    .unwrap();
            assert_eq!(report["verdict"], "accepted");
            let row = catalogue.generate_row(boxed).unwrap();
            assert_eq!(
                row.certificate_bytes(),
                original,
                "complete original source-specific bytes: {name} {boxed:?}"
            );
            rows.push(json!({"original":file,"module":row.module_name(),"case":boxed,"all_U_cases":catalogue.case_tags().len(),"all_source_types":catalogue.source_types().len(),"whole_bytes":original.len(),"raw_sha256":format!("{:x}",Sha256::digest(&original)),"fresh_unary_fix_producer_bytes_equal_original":true}));
        }
    }
    if let Some(out) = std::env::var_os("MPK_GO_SOURCE_VALUE_RELATIONS_OUTPUT") {
        write(&PathBuf::from(out),"producer-replay.json",&serde_json::to_vec_pretty(&json!({"status":"complete_source_libraries_and_boundary_rows_unchanged","streams":rows,"not_a_repeated_kernel_matrix":true})).unwrap());
    }
}
