//! Core term, level, declaration, context, reduction, and definitional equality crate.

#![forbid(unsafe_code)]

pub mod bool_cases;
pub mod bool_rec_type;
pub mod context;
pub mod decl_check;
pub mod defeq;
pub mod env;
pub mod error;
pub mod inductive;
pub mod inductive_gen;
pub mod infer;
pub mod level;
pub mod name;
pub mod nat_induct;
pub mod positivity;
pub mod reduce;
pub mod reduce_inductive;
pub mod subst;
pub mod term;

pub use bool_cases::check_bool_cases_declaration;
pub use bool_rec_type::check_bool_rec_type_declaration;
pub use context::{LocalContext, LocalDecl, LocalDefinition};
pub use decl_check::{check_theorem, register_checked_theorem};
pub use defeq::{definitionally_equal, definitionally_equal_with_fuel, DEFAULT_DEFEQ_FUEL};
pub use env::{
    Declaration, DeclarationKind, DefinitionReducibility, Environment, EnvironmentCacheKey,
};
pub use error::{CoreError, CoreErrorCode, CoreLocation, CoreLocationPart};
pub use inductive::{
    export_registered_inductive, register_mvp_inductive, ConstructorSignature, ExportedInductive,
    ExportedInductiveDeclaration, InductiveSpec, MvpInductiveShape, RecursorSignature,
    RegisteredInductive,
};
pub use inductive_gen::{
    generate_bool_cases_declaration, generate_mvp_inductive_declarations, GeneratedArtifact,
    GeneratedArtifactHash, GeneratedArtifactKind, GeneratedInductiveDeclarations,
    InductiveGenerationInput,
};
pub use infer::{check, infer, infer_sort};
pub use level::{LevelArena, LevelHash, LevelId, LevelNode};
pub use name::{GlobalId, Name, NameError, NameResolver};
pub use nat_induct::check_nat_induct_declaration;
pub use positivity::{check_mvp_positivity, PositivityErrorKind};
pub use reduce::{whnf, whnf_with_fuel, ReduceError, DEFAULT_WHNF_FUEL};
pub use reduce_inductive::{
    reduce_generated_recursor_iota, reduce_generated_recursor_iota_with_fuel,
    IotaReductionErrorKind, DEFAULT_IOTA_FUEL,
};
pub use subst::{beta_substitute, lift, lift_from, substitute, substitute_top, SubstError};
pub use term::{TermArena, TermHash, TermId, TermNode};
