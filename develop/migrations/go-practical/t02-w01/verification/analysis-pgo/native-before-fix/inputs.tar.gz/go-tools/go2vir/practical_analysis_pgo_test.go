//go:build go1.25 && (linux || darwin)

package main

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

// The real Go compiler's default profile is an additional input, even when
// an explicit -pgo=off later makes it inactive. Keep every original source and
// add the exact registered SDK profile only in an independent restored copy.
func TestPracticalAnalysisCapturesDefaultPGO(t *testing.T) {
	frontend := restoreRegisteredAnalysisOriginal(t)
	profile, err := os.ReadFile(filepath.Join(runtime.GOROOT(), "src", "cmd", "compile", "default.pgo"))
	if err != nil || len(profile) == 0 {
		t.Fatalf("read the real Go compiler profile: %v", err)
	}
	if err := os.WriteFile(filepath.Join(frontend, "default.pgo"), profile, 0o644); err != nil {
		t.Fatal(err)
	}
	roots := practicalAnalysisTestRoots(t, frontend)
	session := practicalTestSession(t, roots)
	inputs, err := session.capturePracticalAnalysis(practicalModuleLocation{capability: roots[0].Capability}, practicalModuleLocation{capability: roots[1].Capability})
	if err != nil {
		t.Fatal(err)
	}
	snapshot, err := session.seal()
	if err != nil {
		t.Fatal(err)
	}
	wire, err := snapshot.snapshotInputs()
	if err != nil {
		t.Fatal(err)
	}
	if len(inputs.sources) != 48 || len(inputs.vendor) != 133 {
		t.Fatal("original registered analysis files were narrowed")
	}
	var objects []practicalSourceObject
	for _, source := range inputs.buildSources() {
		objects = append(objects, source.sourceObject())
	}
	var rows []struct {
		Object  practicalSourceObject `json:"object"`
		RawFile string                `json:"raw_file"`
	}
	out := os.Getenv("MPK_GO_ANALYSIS_PGO_OUTPUT")
	if out != "" {
		if err := os.MkdirAll(filepath.Join(out, "original-bytes"), 0o700); err != nil {
			t.Fatal(err)
		}
		for _, source := range wire.sources {
			raw := source.sourceBytes()
			name := source.object.RawSHA256 + ".raw"
			file := filepath.Join(out, "original-bytes", name)
			old, readErr := os.ReadFile(file)
			if os.IsNotExist(readErr) {
				if err := os.WriteFile(file, raw, 0o600); err != nil {
					t.Fatal(err)
				}
			} else if readErr != nil || !bytes.Equal(old, raw) {
				t.Fatal("original byte identity differs")
			}
			rows = append(rows, struct {
				Object  practicalSourceObject `json:"object"`
				RawFile string                `json:"raw_file"`
			}{source.object, name})
		}
		if err := os.WriteFile(filepath.Join(out, "original-profile.raw"), profile, 0o600); err != nil {
			t.Fatal(err)
		}
	}
	plans := make(map[string]string)
	for _, mode := range []string{"auto", "off"} {
		args := []string{"build", "-n", "-mod=vendor", "-trimpath", "-buildvcs=false", "-ldflags=-buildid="}
		if mode == "off" {
			args = append(args, "-pgo=off")
		}
		args = append(args, "-o", filepath.Join(t.TempDir(), "go2vir"), ".")
		command := exec.Command(filepath.Join(runtime.GOROOT(), "bin", "go"), args...)
		command.Dir = frontend
		command.Env = []string{"PATH=" + filepath.Join(runtime.GOROOT(), "bin") + ":/usr/bin:/bin", "HOME=" + t.TempDir(), "GOROOT=" + runtime.GOROOT(), "GOCACHE=" + os.Getenv("GOCACHE"), "GOENV=off", "GOFLAGS=", "GOWORK=off", "GOPROXY=off", "GOSUMDB=off", "GOTOOLCHAIN=local", "CGO_ENABLED=0", "GOOS=linux", "GOARCH=amd64", "GOAMD64=v1"}
		result, err := command.CombinedOutput()
		if err != nil {
			t.Fatalf("Go %s build plan: %v\n%s", mode, err, result)
		}
		plans[mode] = string(result)
		if out != "" {
			if err := os.WriteFile(filepath.Join(out, "plan-"+mode+".log"), result, 0o600); err != nil {
				t.Fatal(err)
			}
		}
	}
	if !strings.Contains(plans["auto"], "default.pgo") || strings.Contains(plans["off"], "default.pgo") {
		t.Fatal("actual Go plans did not distinguish automatic profile use from -pgo=off")
	}
	var archiveIDs []string
	for _, module := range inputs.modules {
		archiveIDs = append(archiveIDs, module.archive.source.object.ID)
	}
	if out != "" {
		packet := map[string]any{"snapshot_hex": hex.EncodeToString(wire.canonical), "source_ids": snapshot.ids, "original_sources": rows, "manifest_source_id": inputs.vendorManifest.object.ID, "archive_source_ids": archiveIDs, "build_objects": objects, "profile_sha256": sha256Hex(profile), "profile_bytes": len(profile), "native_auto_plan_uses_profile": true, "native_off_plan_uses_profile": false, "original_frontend_go_files": len(inputs.sources), "original_vendor_files": len(inputs.vendor), "application_proof_claimed": false}
		raw, err := json.MarshalIndent(packet, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(out, "native.json"), append(raw, '\n'), 0o600); err != nil {
			t.Fatal(err)
		}
	}
	captured, err := snapshot.readSource(roots[0].Capability, "default.pgo", "auxiliary")
	if err != nil || !bytes.Equal(captured.sourceBytes(), profile) {
		t.Fatalf("automatic PGO profile was not captured exactly: %v", err)
	}
	found := false
	for _, object := range objects {
		if object.Path == "default.pgo" && object.ID == captured.object.ID {
			found = true
		}
	}
	if !found || len(wire.sources) != 197 || len(objects) != 185 {
		t.Fatalf("complete original build list does not retain its PGO input: objects=%d build=%d", len(wire.sources), len(objects))
	}
}
