//! Validate a real Go compiler profile without replacing any original source.
use mpk_vc::go_practical_type_keys::{
    check_go_analysis_module_inputs, check_go_analysis_source_inputs,
    check_go_analysis_vendor_snapshot, import_go_source_snapshot_inputs,
    parse_go_analysis_vendor_manifest, GoAnalysisSourceError, GoAnalysisSourceInputs,
    GoSourceSnapshotLookupError, GoTypeSourceBuffer,
};
use serde_json::Value;
use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

fn evidence(name: &str) -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../develop/migrations/go-practical/t02-w01/verification/analysis-pgo")
        .join(name)
}
fn unhex(text: &str) -> Vec<u8> {
    assert_eq!(text.len() % 2, 0);
    text.as_bytes()
        .chunks_exact(2)
        .map(|pair| u8::from_str_radix(std::str::from_utf8(pair).unwrap(), 16).unwrap())
        .collect()
}
fn read(path: &Path) -> Value {
    serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap()
}
fn analysis(
    directory: &Path,
    packet: &Value,
) -> Result<GoAnalysisSourceInputs, GoAnalysisSourceError> {
    let mut sources = BTreeMap::new();
    for row in packet["original_sources"].as_array().unwrap() {
        let raw = std::fs::read(
            directory
                .join("original-bytes")
                .join(row["raw_file"].as_str().unwrap()),
        )
        .unwrap();
        let source =
            GoTypeSourceBuffer::import(&serde_json::to_vec(&row["object"]).unwrap(), &raw).unwrap();
        assert!(sources.insert(source.object().id.clone(), source).is_none());
    }
    let buffers = packet["source_ids"]
        .as_array()
        .unwrap()
        .iter()
        .map(|id| sources[id.as_str().unwrap()].clone())
        .collect::<Vec<_>>();
    let snapshot = import_go_source_snapshot_inputs(
        &unhex(packet["snapshot_hex"].as_str().unwrap()),
        &buffers,
    )
    .unwrap();
    let manifest = sources[packet["manifest_source_id"].as_str().unwrap()].clone();
    let archives = packet["archive_source_ids"]
        .as_array()
        .unwrap()
        .iter()
        .map(|id| sources[id.as_str().unwrap()].clone())
        .collect();
    let vendor = check_go_analysis_vendor_snapshot(
        snapshot,
        parse_go_analysis_vendor_manifest(manifest).unwrap(),
        archives,
    )
    .unwrap();
    check_go_analysis_source_inputs(check_go_analysis_module_inputs(vendor).unwrap())
}

#[test]
fn observed_but_uncaptured_default_profile_rejects() {
    let root = evidence("native-before-fix");
    let packet = read(&root.join("native.json"));
    assert_eq!(packet["original_sources"].as_array().unwrap().len(), 196);
    assert_eq!(packet["build_objects"].as_array().unwrap().len(), 184);
    assert_eq!(packet["native_auto_plan_uses_profile"], true);
    assert_eq!(packet["native_off_plan_uses_profile"], false);
    let result = analysis(&root, &packet);
    assert!(
        matches!(
            result,
            Err(GoAnalysisSourceError::Snapshot(
                GoSourceSnapshotLookupError::NotCaptured
            ))
        ),
        "an observed default profile without captured bytes must reject"
    );
}

#[test]
fn exact_default_profile_joins_every_original_build_input() {
    let root = evidence("native-after-fix");
    let packet = read(&root.join("native.json"));
    assert_eq!(packet["original_sources"].as_array().unwrap().len(), 197);
    assert_eq!(packet["build_objects"].as_array().unwrap().len(), 185);
    assert_eq!(packet["native_auto_plan_uses_profile"], true);
    assert_eq!(packet["native_off_plan_uses_profile"], false);
    let owner = analysis(&root, &packet)
        .expect("the full original source and exact PGO profile must be owned");
    let build = owner.build_sources();
    assert_eq!(build.len(), 185);
    let profile = build
        .iter()
        .find(|source| source.object().path == "default.pgo")
        .expect("profile in original build inputs");
    assert_eq!(profile.object().kind, "auxiliary");
    assert_eq!(
        profile.object().raw_sha256,
        packet["profile_sha256"].as_str().unwrap()
    );
    assert_eq!(
        profile.bytes(),
        std::fs::read(root.join("original-profile.raw")).unwrap()
    );
    assert_eq!(
        owner.module().vendor().snapshot().source_objects().len(),
        197
    );
    let prior = read(&evidence("native-before-fix").join("native.json"));
    let old_ids = prior["source_ids"].as_array().unwrap();
    let new_ids = packet["source_ids"].as_array().unwrap();
    assert_eq!(old_ids.len(), 196);
    assert!(
        old_ids.iter().all(|id| new_ids.contains(id)),
        "every original source object remains"
    );
}
