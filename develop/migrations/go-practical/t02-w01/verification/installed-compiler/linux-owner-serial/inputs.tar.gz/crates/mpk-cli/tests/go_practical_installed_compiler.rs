//! Exercise the unchanged private boundary from an actual installed bin/mpk.
//! The outer driver materializes every registered Go/Rust bundle byte.
#[path = "../src/frontend_registry.rs"]
#[allow(unused_imports)]
mod frontend_registry;
#[path = "../src/go_practical_installed_compiler.rs"]
#[allow(dead_code)]
mod go_practical_installed_compiler;

use go_practical_installed_compiler::{InstalledGoCompiler, InstalledGoCompilerError};
use mpk_vc::go_practical_type_keys::*;
use serde_json::{json, Value};
use std::path::Path;

fn unhex(value: &str) -> Vec<u8> {
    assert!(value.len().is_multiple_of(2));
    value
        .as_bytes()
        .chunks_exact(2)
        .map(|b| u8::from_str_radix(std::str::from_utf8(b).unwrap(), 16).unwrap())
        .collect()
}

fn buffers(packet: &Value, field: &str, directory: &Path) -> Vec<GoTypeSourceBuffer> {
    packet[field]
        .as_array()
        .unwrap()
        .iter()
        .map(|row| {
            let raw = if let Some(raw) = row["raw_hex"].as_str() {
                unhex(raw)
            } else {
                let file = row["raw_file"].as_str().unwrap();
                assert!(
                    file.len() == 68
                        && file.ends_with(".raw")
                        && file[..64].bytes().all(|b| b.is_ascii_hexdigit())
                );
                std::fs::read(directory.join("original-source-objects").join(file)).unwrap()
            };
            GoTypeSourceBuffer::import(&serde_json::to_vec(&row["object"]).unwrap(), &raw).unwrap()
        })
        .collect()
}

fn exports(packet: &Value, directory: &Path) -> GoSourceExportInputs {
    let selection = import_go_source_selection_inputs(
        &unhex(packet["selection_hex"].as_str().unwrap()),
        &unhex(packet["envelope_hex"].as_str().unwrap()),
        &unhex(packet["components_hex"].as_str().unwrap()),
        &buffers(packet, "sources", directory),
        &buffers(packet, "overlays", directory),
    )
    .unwrap();
    let snapshot = import_go_source_snapshot_inputs(
        &unhex(packet["snapshot_hex"].as_str().unwrap()),
        &buffers(packet, "snapshot_sources", directory),
    )
    .unwrap();
    let capture = import_go_source_capture_inputs(
        &unhex(packet["capture_hex"].as_str().unwrap()),
        selection,
        snapshot,
    )
    .unwrap();
    import_go_source_export_inputs(
        &unhex(packet["export_inputs_hex"].as_str().unwrap()),
        capture,
    )
    .unwrap()
}

fn main() {
    let args = std::env::args().skip(1).collect::<Vec<_>>();
    if args.is_empty() {
        assert!(
            matches!(
                InstalledGoCompiler::open(),
                Err(InstalledGoCompilerError::Release)
            ),
            "uninstalled executable acquired installed authority"
        );
        return;
    }
    let authority = match InstalledGoCompiler::open() {
        Ok(authority) => authority,
        Err(error) => {
            println!(
                "{}",
                json!({"status":"rejected", "phase":"installed", "error":format!("{error:?}")})
            );
            return;
        }
    };
    let result = match args.as_slice() {
        [mode] if mode == "--snapshot" => {
            json!({"status":"accepted", "phase":"installed", "toolchain":authority.identity(), "inventory":authority.inventory()})
        }
        [mode, directory, record] if mode == "--bind" => {
            let directory = Path::new(directory);
            let packet: Value = serde_json::from_slice(
                &std::fs::read(directory.join("complete-original-module-graph-inputs.json"))
                    .unwrap(),
            )
            .unwrap();
            let inputs = exports(&packet, directory);
            let record = if record == "original" {
                unhex(packet["compiler_inputs_hex"].as_str().unwrap())
            } else {
                std::fs::read(record).unwrap()
            };
            match authority.bind_original_inputs(&record, inputs) {
                Ok(bound) => {
                    let compiler = bound.compiler_inputs();
                    json!({"status":"accepted", "phase":"bound", "release_registry":bound.release_registry(), "compiler_record":serde_json::from_slice::<Value>(compiler.canonical_bytes()).unwrap(), "files":compiler.files().len(), "bytes":compiler.files().iter().map(|f| f.bytes().len()).sum::<usize>(), "sdk_sources":compiler.sdk_source_files().len(), "sdk_source_directories":compiler.source_index().package_paths().len(), "original_objects":packet["snapshot_sources"].as_array().unwrap().len(), "original_packages":serde_json::from_slice::<Value>(compiler.export_inputs().canonical_bytes()).unwrap()["packages"].as_array().unwrap().len()})
                }
                Err(error) => {
                    json!({"status":"rejected", "phase":"binding", "error":format!("{error:?}")})
                }
            }
        }
        _ => panic!("unexpected installed compiler test arguments"),
    };
    println!("{result}");
}
