use crate::cli::{LowerRequest, RustTarget};
use crate::driver_protocol::{self, DriverComponentIdentity, DriverReleaseIdentity};
use crate::environment::{
    EvidenceEnvironment, ARGUMENT_PROFILE_ID, CARGO_PATH, DRIVER_OUTPUT_ROOT,
    ENVIRONMENT_PROFILE_ID, FRONTEND_ROOT, HOME_ROOT, INPUT_ROOT, NATIVE_RUNTIME_ROOT, TARGET_ROOT,
    TEMP_ROOT, TOOLCHAIN_ROOT, WORK_ROOT,
};
use crate::sha256::{digest, hex};
use crate::snapshot::Snapshot;
use std::collections::{BTreeMap, BTreeSet};
use std::fs::{self, File, Metadata, OpenOptions};
use std::io::{self, Read, Seek, SeekFrom, Write};
use std::path::{Component, Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};

#[cfg(target_os = "linux")]
use std::process::{Command, Stdio};
#[cfg(target_os = "linux")]
use std::sync::atomic::AtomicBool;
#[cfg(target_os = "linux")]
use std::sync::Arc;
#[cfg(target_os = "linux")]
use std::thread;
#[cfg(target_os = "linux")]
use std::time::{Duration, Instant};

#[cfg(target_os = "linux")]
use std::os::fd::AsRawFd;
#[cfg(target_os = "linux")]
use std::os::unix::fs::OpenOptionsExt;
#[cfg(unix)]
use std::os::unix::fs::{MetadataExt, PermissionsExt};

pub const EXECUTION_HOST_PROFILE_ID: &str = "mpk.host.linux-x86_64-gnu.glibc2_27.cgroup2_tmpfs.v0";
pub const RUNTIME_LAYOUT_PROFILE_ID: &str =
    "mpk.runtime.linux-x86_64-gnu.glibc2_27.cgroup2_tmpfs.v0";
pub const FRONTEND_BUNDLE_ID: &str = crate::successor::FRONTEND_ID;
pub const TOOLCHAIN_BUNDLE_ID: &str = crate::successor::TOOLCHAIN_ID;
pub const LIMIT_PROFILE_ID: &str = "mpk.vir.limits.v0";

pub const RESOURCE_PROFILE_ID: &str = "mpk.rust.build_resources.cgroup2_tmpfs.v0";
pub const CGROUP_TASK_LIMIT: u64 = 256;
pub const OPEN_FILE_LIMIT: u64 = 1_024;
pub const VIRTUAL_MEMORY_LIMIT: u64 = 17_179_869_184;
pub const CGROUP_MEMORY_LIMIT: u64 = 34_359_738_368;
pub const CGROUP_SWAP_LIMIT: u64 = 0;
pub const WRITABLE_ALLOCATED_BYTES_LIMIT: u64 = 21_474_836_480;
pub const WRITABLE_INODE_LIMIT: u64 = 262_144;
pub const STDOUT_BYTES_LIMIT: usize =
    crate::limits::RustLimitId::CargoRustcStdout.maximum() as usize;
pub const STDERR_BYTES_LIMIT: usize =
    crate::limits::RustLimitId::CargoRustcStderr.maximum() as usize;
#[cfg(target_os = "linux")]
const CHILD_WALL_CLOCK_TIMEOUT: Duration = Duration::from_secs(300);
const CANDIDATE_FILE_COUNT_LIMIT: usize = 1_048_576;
const CANDIDATE_FILE_SIZE_LIMIT: u64 = 4_294_967_296;
const CANDIDATE_AGGREGATE_LIMIT: u64 = 34_359_738_368;
const CANDIDATE_PATH_LIMIT: usize = 1_024;

static NEXT_INVOCATION: AtomicU64 = AtomicU64::new(0);
#[cfg(target_os = "linux")]
static OUTER_SANDBOX_ACTIVE: AtomicBool = AtomicBool::new(false);

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct InventoryFile {
    path: String,
    executable: bool,
    size_bytes: u64,
    sha256: String,
}

impl InventoryFile {
    pub fn new(
        path: impl Into<String>,
        executable: bool,
        size_bytes: u64,
        sha256: impl Into<String>,
    ) -> Result<Self, SandboxError> {
        let value = Self {
            path: path.into(),
            executable,
            size_bytes,
            sha256: sha256.into(),
        };
        value.validate_shape()?;
        Ok(value)
    }

    pub fn path(&self) -> &str {
        &self.path
    }

    pub fn executable(&self) -> bool {
        self.executable
    }

    pub fn size_bytes(&self) -> u64 {
        self.size_bytes
    }

    pub fn sha256(&self) -> &str {
        &self.sha256
    }

    fn validate_shape(&self) -> Result<(), SandboxError> {
        validate_relative_path(&self.path)?;
        validate_sha256(&self.sha256)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetLibrary {
    target: RustTarget,
    pointer_width: u8,
    component_name: String,
    component_content_sha256: String,
    path_prefix: String,
}

impl TargetLibrary {
    pub fn new(
        target: RustTarget,
        pointer_width: u8,
        component_name: impl Into<String>,
        component_content_sha256: impl Into<String>,
        path_prefix: impl Into<String>,
    ) -> Result<Self, SandboxError> {
        let value = Self {
            target,
            pointer_width,
            component_name: component_name.into(),
            component_content_sha256: component_content_sha256.into(),
            path_prefix: path_prefix.into(),
        };
        if value.pointer_width != value.target.pointer_width()
            || value.component_name.is_empty()
            || !value
                .component_name
                .bytes()
                .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'.' | b'_' | b'-'))
        {
            return Err(SandboxError::ToolchainTarget);
        }
        validate_sha256(&value.component_content_sha256)?;
        validate_relative_path(value.path_prefix.trim_end_matches('/'))?;
        if !value.path_prefix.ends_with('/') {
            return Err(SandboxError::ToolchainTarget);
        }
        Ok(value)
    }

    pub fn target(&self) -> RustTarget {
        self.target
    }

    pub fn component_name(&self) -> &str {
        &self.component_name
    }

    pub fn component_content_sha256(&self) -> &str {
        &self.component_content_sha256
    }
}

#[derive(Clone, Debug)]
pub struct InjectedCandidate {
    frontend_bundle_id: String,
    frontend_root: PathBuf,
    frontend_inventory: Vec<InventoryFile>,
    toolchain_bundle_id: String,
    toolchain_distribution_sha256: String,
    toolchain_root: PathBuf,
    toolchain_inventory: Vec<InventoryFile>,
    target_libraries: Vec<TargetLibrary>,
    execution_host_profile_id: String,
    runtime_layout_profile_id: String,
    driver_release_identity: DriverReleaseIdentity,
}

#[derive(Clone, Debug)]
pub struct CandidateDefinition {
    pub frontend_bundle_id: String,
    pub frontend_bundle_sha256: String,
    pub frontend_root: PathBuf,
    pub frontend_inventory: Vec<InventoryFile>,
    pub toolchain_bundle_id: String,
    pub toolchain_distribution_sha256: String,
    pub toolchain_root: PathBuf,
    pub toolchain_inventory: Vec<InventoryFile>,
    pub target_libraries: Vec<TargetLibrary>,
    pub execution_host_profile_id: String,
    pub runtime_layout_profile_id: String,
    pub environment_profile_id: String,
    pub argument_profile_id: String,
    pub limit_profile_id: String,
    pub compiler_release: String,
    pub compiler_commit: String,
    pub native_runtime_component_root: String,
    pub native_runtime_content_sha256: String,
    pub driver_release_identity: DriverReleaseIdentity,
}

impl InjectedCandidate {
    pub fn from_installed(request: &LowerRequest) -> Result<Self, SandboxError> {
        let driver_name = request
            .release
            .driver
            .file_name()
            .and_then(|name| name.to_str());
        let bin = request
            .release
            .driver
            .parent()
            .filter(|path| path.file_name().and_then(|name| name.to_str()) == Some("bin"));
        if driver_name != Some("rust2vir-driver") {
            return Err(SandboxError::ToolchainComponent);
        }
        let frontend_root = bin
            .and_then(Path::parent)
            .ok_or(SandboxError::ToolchainComponent)?
            .to_path_buf();
        let toolchain_root = request.release.toolchain_root.clone();
        let frontend_inventory = inventory_from_root(&frontend_root)?;
        let toolchain_inventory = inventory_from_root(&toolchain_root)?;
        let frontend_bundle_sha256 =
            frontend_bundle_sha256(FRONTEND_BUNDLE_ID, &frontend_inventory);
        let toolchain_distribution_sha256 =
            toolchain_distribution_sha256(TOOLCHAIN_BUNDLE_ID, &toolchain_inventory);
        if request.release.frontend_bundle_id != FRONTEND_BUNDLE_ID
            || request.release.toolchain_bundle_id != TOOLCHAIN_BUNDLE_ID
            || request.release.toolchain_distribution_sha256 != toolchain_distribution_sha256
            || required_file(&frontend_inventory, "bin/rust2vir", true)?.sha256
                != request.release.frontend_sha256
            || required_file(&frontend_inventory, "bin/rust2vir-driver", true)?.sha256
                != request.release.driver_sha256
        {
            return Err(SandboxError::ToolchainComponent);
        }

        let i686_content_sha256 = component_content_sha256(
            TOOLCHAIN_BUNDLE_ID,
            "rust-target-i686",
            &toolchain_inventory,
            "lib/rustlib/i686-unknown-linux-gnu/",
        );
        let x86_64_content_sha256 = component_content_sha256(
            TOOLCHAIN_BUNDLE_ID,
            "rust-target-x86_64",
            &toolchain_inventory,
            "lib/rustlib/x86_64-unknown-linux-gnu/",
        );
        let native_runtime_content_sha256 = component_content_sha256(
            TOOLCHAIN_BUNDLE_ID,
            "native-runtime",
            &toolchain_inventory,
            "native-runtime/",
        );
        let compiler_runtime = toolchain_inventory
            .iter()
            .filter(|file| {
                file.path.starts_with("lib/")
                    && !file.path.contains("/rustlib/i686-unknown-linux-gnu/")
                    && !file.path.contains("/rustlib/x86_64-unknown-linux-gnu/")
                    && (file.path.ends_with(".so") || file.path.contains(".so."))
            })
            .cloned()
            .collect::<Vec<_>>();
        if compiler_runtime.is_empty() {
            return Err(SandboxError::ToolchainComponent);
        }
        let compiler_runtime_content_sha256 = inventory_content_sha256(
            TOOLCHAIN_BUNDLE_ID,
            "component",
            Some("rust-compiler-runtime"),
            &compiler_runtime,
        );
        let cargo_sha256 = required_file(&toolchain_inventory, "bin/cargo", true)?
            .sha256
            .clone();
        let rustc_sha256 = required_file(&toolchain_inventory, "bin/rustc", true)?
            .sha256
            .clone();
        let frontend_sha256 = required_file(&frontend_inventory, "bin/rust2vir", true)?
            .sha256
            .clone();
        let driver_sha256 = required_file(&frontend_inventory, "bin/rust2vir-driver", true)?
            .sha256
            .clone();

        Self::from_definition(CandidateDefinition {
            frontend_bundle_id: FRONTEND_BUNDLE_ID.to_owned(),
            frontend_bundle_sha256,
            frontend_root,
            frontend_inventory,
            toolchain_bundle_id: TOOLCHAIN_BUNDLE_ID.to_owned(),
            toolchain_distribution_sha256: toolchain_distribution_sha256.clone(),
            toolchain_root,
            toolchain_inventory,
            target_libraries: vec![
                TargetLibrary::new(
                    RustTarget::I686UnknownLinuxGnu,
                    32,
                    "rust-target-i686",
                    i686_content_sha256.clone(),
                    "lib/rustlib/i686-unknown-linux-gnu/",
                )?,
                TargetLibrary::new(
                    RustTarget::X86_64UnknownLinuxGnu,
                    64,
                    "rust-target-x86_64",
                    x86_64_content_sha256.clone(),
                    "lib/rustlib/x86_64-unknown-linux-gnu/",
                )?,
            ],
            execution_host_profile_id: EXECUTION_HOST_PROFILE_ID.to_owned(),
            runtime_layout_profile_id: RUNTIME_LAYOUT_PROFILE_ID.to_owned(),
            environment_profile_id: ENVIRONMENT_PROFILE_ID.to_owned(),
            argument_profile_id: ARGUMENT_PROFILE_ID.to_owned(),
            limit_profile_id: LIMIT_PROFILE_ID.to_owned(),
            compiler_release: crate::EXPECTED_RUSTC_RELEASE.to_owned(),
            compiler_commit: crate::EXPECTED_RUSTC_COMMIT.to_owned(),
            native_runtime_component_root: "native-runtime".to_owned(),
            native_runtime_content_sha256: native_runtime_content_sha256.clone(),
            driver_release_identity: DriverReleaseIdentity {
                frontend_bundle_id: FRONTEND_BUNDLE_ID.to_owned(),
                frontend_binary_sha256: frontend_sha256,
                driver_binary_sha256: driver_sha256,
                toolchain_bundle_id: TOOLCHAIN_BUNDLE_ID.to_owned(),
                toolchain_distribution_sha256,
                toolchain_components: vec![
                    DriverComponentIdentity {
                        kind: "executable".to_owned(),
                        name: "cargo".to_owned(),
                        release: crate::EXPECTED_RUSTC_RELEASE.to_owned(),
                        sha256: cargo_sha256,
                        commit_hash: None,
                    },
                    DriverComponentIdentity {
                        kind: "content".to_owned(),
                        name: "native-runtime".to_owned(),
                        release: "nightly-2025-06-01".to_owned(),
                        sha256: native_runtime_content_sha256,
                        commit_hash: None,
                    },
                    DriverComponentIdentity {
                        kind: "content".to_owned(),
                        name: "rust-compiler-runtime".to_owned(),
                        release: "nightly-2025-06-01".to_owned(),
                        sha256: compiler_runtime_content_sha256,
                        commit_hash: None,
                    },
                    DriverComponentIdentity {
                        kind: "content".to_owned(),
                        name: "rust-target-i686".to_owned(),
                        release: "nightly-2025-06-01".to_owned(),
                        sha256: i686_content_sha256,
                        commit_hash: None,
                    },
                    DriverComponentIdentity {
                        kind: "content".to_owned(),
                        name: "rust-target-x86_64".to_owned(),
                        release: "nightly-2025-06-01".to_owned(),
                        sha256: x86_64_content_sha256,
                        commit_hash: None,
                    },
                    DriverComponentIdentity {
                        kind: "executable".to_owned(),
                        name: "rustc".to_owned(),
                        release: crate::EXPECTED_RUSTC_RELEASE.to_owned(),
                        sha256: rustc_sha256,
                        commit_hash: Some(crate::EXPECTED_RUSTC_COMMIT.to_owned()),
                    },
                ],
            },
        })
    }

    pub fn from_definition(definition: CandidateDefinition) -> Result<Self, SandboxError> {
        validate_sha256(&definition.frontend_bundle_sha256)?;
        validate_sha256(&definition.toolchain_distribution_sha256)?;
        validate_inventory_shape(&definition.frontend_inventory)?;
        validate_inventory_shape(&definition.toolchain_inventory)?;
        let frontend_sha256 = frontend_bundle_sha256(
            &definition.frontend_bundle_id,
            &definition.frontend_inventory,
        );
        let distribution_sha256 = toolchain_distribution_sha256(
            &definition.toolchain_bundle_id,
            &definition.toolchain_inventory,
        );
        let native_runtime_sha256 = component_content_sha256(
            &definition.toolchain_bundle_id,
            "native-runtime",
            &definition.toolchain_inventory,
            "native-runtime/",
        );
        if definition.frontend_bundle_id != FRONTEND_BUNDLE_ID
            || definition.toolchain_bundle_id != TOOLCHAIN_BUNDLE_ID
            || definition.execution_host_profile_id != EXECUTION_HOST_PROFILE_ID
            || definition.runtime_layout_profile_id != RUNTIME_LAYOUT_PROFILE_ID
            || definition.environment_profile_id != ENVIRONMENT_PROFILE_ID
            || definition.argument_profile_id != ARGUMENT_PROFILE_ID
            || definition.limit_profile_id != LIMIT_PROFILE_ID
            || definition.compiler_release != crate::EXPECTED_RUSTC_RELEASE
            || definition.compiler_commit != crate::EXPECTED_RUSTC_COMMIT
            || definition.native_runtime_component_root != "native-runtime"
            || !definition
                .toolchain_inventory
                .iter()
                .any(|file| file.path.starts_with("native-runtime/"))
            || definition.frontend_bundle_sha256 != frontend_sha256
            || definition.toolchain_distribution_sha256 != distribution_sha256
            || definition.native_runtime_content_sha256 != native_runtime_sha256
            || definition.target_libraries.len() != 2
            || definition.target_libraries[0].target != RustTarget::I686UnknownLinuxGnu
            || definition.target_libraries[1].target != RustTarget::X86_64UnknownLinuxGnu
            || definition.target_libraries[0].component_name != "rust-target-i686"
            || definition.target_libraries[1].component_name != "rust-target-x86_64"
            || validate_driver_release_identity(&definition).is_err()
        {
            return Err(SandboxError::ToolchainComponent);
        }
        for target in &definition.target_libraries {
            if !definition
                .toolchain_inventory
                .iter()
                .any(|file| file.path.starts_with(&target.path_prefix))
                || target.component_content_sha256
                    != component_content_sha256(
                        &definition.toolchain_bundle_id,
                        &target.component_name,
                        &definition.toolchain_inventory,
                        &target.path_prefix,
                    )
            {
                return Err(SandboxError::ToolchainTarget);
            }
        }
        Ok(Self {
            frontend_bundle_id: definition.frontend_bundle_id,
            frontend_root: definition.frontend_root,
            frontend_inventory: definition.frontend_inventory,
            toolchain_bundle_id: definition.toolchain_bundle_id,
            toolchain_distribution_sha256: definition.toolchain_distribution_sha256,
            toolchain_root: definition.toolchain_root,
            toolchain_inventory: definition.toolchain_inventory,
            target_libraries: definition.target_libraries,
            execution_host_profile_id: definition.execution_host_profile_id,
            runtime_layout_profile_id: definition.runtime_layout_profile_id,
            driver_release_identity: definition.driver_release_identity,
        })
    }

    pub fn frontend_root(&self) -> &Path {
        &self.frontend_root
    }

    pub fn toolchain_root(&self) -> &Path {
        &self.toolchain_root
    }

    pub fn native_runtime_root(&self) -> PathBuf {
        self.toolchain_root.join("native-runtime")
    }

    pub fn driver_release_identity(&self) -> &DriverReleaseIdentity {
        &self.driver_release_identity
    }

    pub fn validate_for(&self, request: &LowerRequest) -> Result<ValidatedCandidate, SandboxError> {
        if request.release.frontend_bundle_id != self.frontend_bundle_id
            || request.release.frontend_sha256
                != self.driver_release_identity.frontend_binary_sha256
            || request.release.toolchain_bundle_id != self.toolchain_bundle_id
            || request.release.toolchain_distribution_sha256 != self.toolchain_distribution_sha256
            || request.release.toolchain_root != self.toolchain_root
            || request.release.driver != self.frontend_root.join("bin/rust2vir-driver")
        {
            return Err(SandboxError::ToolchainComponent);
        }
        let target = self
            .target_libraries
            .iter()
            .find(|library| library.target == request.target)
            .ok_or(SandboxError::ToolchainTarget)?;
        if target.pointer_width != request.target.pointer_width()
            || !self
                .toolchain_inventory
                .iter()
                .any(|file| file.path.starts_with(&target.path_prefix))
        {
            return Err(SandboxError::ToolchainTarget);
        }

        let driver = required_file(&self.frontend_inventory, "bin/rust2vir-driver", true)?;
        if driver.sha256 != request.release.driver_sha256 {
            return Err(SandboxError::ToolchainComponent);
        }
        required_file(&self.frontend_inventory, "bin/rust2vir", true)?;
        required_file(&self.toolchain_inventory, "bin/cargo", true)?;
        required_file(&self.toolchain_inventory, "bin/rustc", true)?;
        required_file(
            &self.toolchain_inventory,
            "native-runtime/lib64/ld-linux-x86-64.so.2",
            true,
        )?;
        for runtime_file in [
            "native-runtime/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2",
            "native-runtime/lib/x86_64-linux-gnu/libc.so.6",
            "native-runtime/lib/x86_64-linux-gnu/libdl.so.2",
            "native-runtime/lib/x86_64-linux-gnu/libgcc_s.so.1",
            "native-runtime/lib/x86_64-linux-gnu/libm.so.6",
            "native-runtime/lib/x86_64-linux-gnu/libpthread.so.0",
            "native-runtime/lib/x86_64-linux-gnu/librt.so.1",
            "native-runtime/lib/x86_64-linux-gnu/libstdcxx.so.6",
            "native-runtime/lib/x86_64-linux-gnu/libtinfo.so.5",
            "native-runtime/lib/x86_64-linux-gnu/libz.so.1",
        ] {
            required_file(&self.toolchain_inventory, runtime_file, false)?;
        }
        if !self
            .toolchain_inventory
            .iter()
            .any(|file| file.path.starts_with("lib/"))
            || !self
                .toolchain_inventory
                .iter()
                .any(|file| file.path.starts_with("native-runtime/"))
        {
            return Err(SandboxError::ToolchainComponent);
        }

        let frontend_handle =
            validate_inventory_root(&self.frontend_root, &self.frontend_inventory)?;
        let toolchain_handle =
            validate_inventory_root(&self.toolchain_root, &self.toolchain_inventory)?;
        validate_distinct_roots(&frontend_handle, &toolchain_handle)?;
        #[cfg(target_os = "linux")]
        let retained_native_runtime = PathBuf::from(format!(
            "/proc/self/fd/{}/native-runtime",
            toolchain_handle.as_raw_fd()
        ));
        #[cfg(not(target_os = "linux"))]
        let retained_native_runtime = self.native_runtime_root();
        let native_runtime_handle = open_directory_nofollow(&retained_native_runtime)?;
        Ok(ValidatedCandidate {
            frontend_root: self.frontend_root.clone(),
            toolchain_root: self.toolchain_root.clone(),
            native_runtime_root: self.native_runtime_root(),
            target: request.target,
            execution_host_profile_id: self.execution_host_profile_id.clone(),
            runtime_layout_profile_id: self.runtime_layout_profile_id.clone(),
            frontend_handle,
            toolchain_handle,
            native_runtime_handle,
        })
    }
}

fn validate_driver_release_identity(definition: &CandidateDefinition) -> Result<(), SandboxError> {
    let identity = &definition.driver_release_identity;
    let compiler_runtime = definition
        .toolchain_inventory
        .iter()
        .filter(|file| {
            file.path.starts_with("lib/")
                && !file.path.contains("/rustlib/i686-unknown-linux-gnu/")
                && !file.path.contains("/rustlib/x86_64-unknown-linux-gnu/")
                && (file.path.ends_with(".so") || file.path.contains(".so."))
        })
        .cloned()
        .collect::<Vec<_>>();
    if compiler_runtime.is_empty() {
        return Err(SandboxError::ToolchainComponent);
    }
    let compiler_runtime_sha256 = inventory_content_sha256(
        &definition.toolchain_bundle_id,
        "component",
        Some("rust-compiler-runtime"),
        &compiler_runtime,
    );
    if identity.frontend_bundle_id != definition.frontend_bundle_id
        || identity.toolchain_bundle_id != definition.toolchain_bundle_id
        || identity.toolchain_distribution_sha256 != definition.toolchain_distribution_sha256
        || identity.frontend_binary_sha256
            != required_file(&definition.frontend_inventory, "bin/rust2vir", true)?.sha256
        || identity.driver_binary_sha256
            != required_file(&definition.frontend_inventory, "bin/rust2vir-driver", true)?.sha256
        || identity.toolchain_components.is_empty()
        || identity
            .toolchain_components
            .iter()
            .map(|component| component.name.as_str())
            .ne([
                "cargo",
                "native-runtime",
                "rust-compiler-runtime",
                "rust-target-i686",
                "rust-target-x86_64",
                "rustc",
            ])
    {
        return Err(SandboxError::ToolchainComponent);
    }
    let mut previous = None;
    for component in &identity.toolchain_components {
        validate_sha256(&component.sha256)?;
        if component.name.is_empty()
            || component.release.is_empty()
            || previous
                .is_some_and(|previous: &str| previous.as_bytes() >= component.name.as_bytes())
        {
            return Err(SandboxError::ToolchainComponent);
        }
        previous = Some(component.name.as_str());
        match (component.kind.as_str(), component.name.as_str()) {
            ("executable", "cargo") => {
                if component.commit_hash.is_some()
                    || component.sha256
                        != required_file(&definition.toolchain_inventory, "bin/cargo", true)?.sha256
                {
                    return Err(SandboxError::ToolchainComponent);
                }
            }
            ("executable", "rustc") => {
                if component.release != definition.compiler_release
                    || component.commit_hash.as_deref() != Some(&definition.compiler_commit)
                    || component.sha256
                        != required_file(&definition.toolchain_inventory, "bin/rustc", true)?.sha256
                {
                    return Err(SandboxError::ToolchainComponent);
                }
            }
            (
                "content",
                "native-runtime"
                | "rust-compiler-runtime"
                | "rust-target-i686"
                | "rust-target-x86_64",
            ) if component.commit_hash.is_none() => {}
            _ => return Err(SandboxError::ToolchainComponent),
        }
    }
    for (name, hash) in [
        (
            "native-runtime",
            definition.native_runtime_content_sha256.as_str(),
        ),
        (
            "rust-target-i686",
            definition.target_libraries[0]
                .component_content_sha256
                .as_str(),
        ),
        ("rust-compiler-runtime", compiler_runtime_sha256.as_str()),
        (
            "rust-target-x86_64",
            definition.target_libraries[1]
                .component_content_sha256
                .as_str(),
        ),
    ] {
        if !identity.toolchain_components.iter().any(|component| {
            component.kind == "content" && component.name == name && component.sha256 == hash
        }) {
            return Err(SandboxError::ToolchainComponent);
        }
    }
    Ok(())
}

#[cfg_attr(not(target_os = "linux"), allow(dead_code))]
pub struct ValidatedCandidate {
    frontend_root: PathBuf,
    toolchain_root: PathBuf,
    native_runtime_root: PathBuf,
    target: RustTarget,
    execution_host_profile_id: String,
    runtime_layout_profile_id: String,
    frontend_handle: File,
    toolchain_handle: File,
    native_runtime_handle: File,
}

impl std::fmt::Debug for ValidatedCandidate {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("ValidatedCandidate")
            .field("frontend_root", &self.frontend_root)
            .field("toolchain_root", &self.toolchain_root)
            .field("native_runtime_root", &self.native_runtime_root)
            .field("target", &self.target)
            .field("execution_host_profile_id", &self.execution_host_profile_id)
            .field("runtime_layout_profile_id", &self.runtime_layout_profile_id)
            .finish_non_exhaustive()
    }
}

impl ValidatedCandidate {
    pub fn frontend_root(&self) -> &Path {
        &self.frontend_root
    }

    pub fn toolchain_root(&self) -> &Path {
        &self.toolchain_root
    }

    pub fn native_runtime_root(&self) -> &Path {
        &self.native_runtime_root
    }

    pub fn target(&self) -> RustTarget {
        self.target
    }

    pub fn execution_host_profile_id(&self) -> &str {
        &self.execution_host_profile_id
    }

    pub fn runtime_layout_profile_id(&self) -> &str {
        &self.runtime_layout_profile_id
    }

    #[cfg(target_os = "linux")]
    fn retained_descriptors(&self) -> [i32; 3] {
        [
            self.frontend_handle.as_raw_fd(),
            self.toolchain_handle.as_raw_fd(),
            self.native_runtime_handle.as_raw_fd(),
        ]
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CargoInvocationKind {
    Metadata,
    Check,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CargoInvocation {
    kind: CargoInvocationKind,
    arguments: Vec<String>,
}

impl CargoInvocation {
    pub fn new(kind: CargoInvocationKind, arguments: &[&str]) -> Result<Self, SandboxError> {
        if arguments.is_empty()
            || arguments
                .iter()
                .any(|argument| argument.is_empty() || argument.contains('\0'))
        {
            return Err(SandboxError::ToolchainArgument);
        }
        Ok(Self {
            kind,
            arguments: arguments
                .iter()
                .map(|argument| (*argument).to_owned())
                .collect(),
        })
    }

    pub fn kind(&self) -> CargoInvocationKind {
        self.kind
    }

    pub fn executable(&self) -> &'static str {
        CARGO_PATH
    }

    pub fn arguments(&self) -> &[String] {
        &self.arguments
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProcessOutput {
    pub exit_code: Option<i32>,
    pub signaled: bool,
    pub stdout: Vec<u8>,
    pub stderr_observed_bytes: usize,
    pub stdout_limit_exceeded: bool,
    pub stderr_limit_exceeded: bool,
}

impl ProcessOutput {
    pub fn success(stdout: impl Into<Vec<u8>>) -> Self {
        Self {
            exit_code: Some(0),
            signaled: false,
            stdout: stdout.into(),
            stderr_observed_bytes: 0,
            stdout_limit_exceeded: false,
            stderr_limit_exceeded: false,
        }
    }

    pub fn succeeded(&self) -> bool {
        self.exit_code == Some(0) && !self.signaled
    }

    pub fn exceeded_stream_limit(&self) -> bool {
        self.stdout_limit_exceeded || self.stderr_limit_exceeded
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SandboxLimits {
    pub cgroup_tasks: u64,
    pub open_files_per_process: u64,
    pub virtual_memory_bytes_per_process: u64,
    pub cgroup_memory_bytes: u64,
    pub cgroup_swap_bytes: u64,
    pub writable_allocated_bytes: u64,
    pub writable_inodes: u64,
    pub stdout_bytes: usize,
    pub stderr_bytes: usize,
}

impl SandboxLimits {
    pub const FROZEN: Self = Self {
        cgroup_tasks: CGROUP_TASK_LIMIT,
        open_files_per_process: OPEN_FILE_LIMIT,
        virtual_memory_bytes_per_process: VIRTUAL_MEMORY_LIMIT,
        cgroup_memory_bytes: CGROUP_MEMORY_LIMIT,
        cgroup_swap_bytes: CGROUP_SWAP_LIMIT,
        writable_allocated_bytes: WRITABLE_ALLOCATED_BYTES_LIMIT,
        writable_inodes: WRITABLE_INODE_LIMIT,
        stdout_bytes: STDOUT_BYTES_LIMIT,
        stderr_bytes: STDERR_BYTES_LIMIT,
    };
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ResourceFilesystemObservation {
    pub filesystem_type: u64,
    pub allocated_capacity_bytes: u64,
    pub inode_capacity: u64,
    pub same_device: bool,
    pub nosuid: bool,
    pub nodev: bool,
    pub noswap: bool,
}

pub fn validate_resource_filesystem_observation(
    observation: ResourceFilesystemObservation,
    limits: SandboxLimits,
) -> Result<(), SandboxError> {
    const TMPFS_MAGIC: u64 = 0x0102_1994;
    if observation.filesystem_type != TMPFS_MAGIC
        || observation.allocated_capacity_bytes != limits.writable_allocated_bytes
        || observation.inode_capacity != limits.writable_inodes
        || !observation.same_device
        || !observation.nosuid
        || !observation.nodev
        || !observation.noswap
    {
        return Err(SandboxError::SandboxUnavailable);
    }
    Ok(())
}

#[derive(Debug)]
#[cfg_attr(not(target_os = "linux"), allow(dead_code))]
pub struct SandboxContext<'a> {
    invocation_id: u64,
    snapshot_root: &'a Path,
    candidate: &'a ValidatedCandidate,
    workspace: &'a InvocationWorkspace,
    environment: &'a EvidenceEnvironment,
    limits: SandboxLimits,
    snapshot_handle: &'a File,
    driver_request: &'a driver_protocol::DriverRequest,
}

impl SandboxContext<'_> {
    pub fn invocation_id(&self) -> u64 {
        self.invocation_id
    }

    pub fn snapshot_root(&self) -> &Path {
        self.snapshot_root
    }

    pub fn candidate(&self) -> &ValidatedCandidate {
        self.candidate
    }

    pub fn environment(&self) -> &EvidenceEnvironment {
        self.environment
    }

    pub fn limits(&self) -> SandboxLimits {
        self.limits
    }

    pub fn writable_host_path(&self, sandbox_path: &str) -> Option<&Path> {
        self.workspace.writable_host_path(sandbox_path)
    }

    pub fn rootfs(&self) -> &Path {
        &self.workspace.rootfs
    }

    pub fn driver_request_host_path(&self) -> &Path {
        self.workspace.driver_request_host_path()
    }

    pub fn driver_request(&self) -> &driver_protocol::DriverRequest {
        self.driver_request
    }

    #[cfg(target_os = "linux")]
    fn retained_descriptors(&self) -> Vec<i32> {
        let [frontend, toolchain, native_runtime] = self.candidate.retained_descriptors();
        let mut descriptors = vec![
            self.snapshot_handle.as_raw_fd(),
            frontend,
            toolchain,
            native_runtime,
        ];
        descriptors.extend(self.workspace.retained_descriptors());
        descriptors
    }
}

pub trait SandboxExecutor {
    fn execute(
        &mut self,
        context: &SandboxContext<'_>,
        invocation: &CargoInvocation,
    ) -> Result<ProcessOutput, SandboxError>;
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SandboxError {
    SandboxUnavailable,
    ToolchainComponent,
    ToolchainTarget,
    ToolchainArgument,
    ChildOutputLimit,
    Spawn,
    Killed,
    FilesystemLimit,
    DriverProtocol(driver_protocol::DriverProtocolCode),
}

impl SandboxError {
    pub fn code(self) -> &'static str {
        match self {
            Self::SandboxUnavailable => "FRONTEND_SANDBOX_UNAVAILABLE",
            Self::ToolchainComponent => "RUST_TOOLCHAIN_COMPONENT",
            Self::ToolchainTarget => "RUST_TOOLCHAIN_TARGET",
            Self::ToolchainArgument => "RUST_TOOLCHAIN_ARGUMENT",
            Self::ChildOutputLimit => "RUST_FRONTEND_CHILD_OUTPUT_LIMIT",
            Self::Spawn | Self::Killed | Self::FilesystemLimit => "RUST_FRONTEND_COMPILER_CRASH",
            Self::DriverProtocol(code) => code.as_str(),
        }
    }
}

pub struct PreparedSandbox<'a, E> {
    request: &'a LowerRequest,
    snapshot: &'a Snapshot,
    candidate_source: &'a InjectedCandidate,
    candidate: ValidatedCandidate,
    snapshot_handle: File,
    environment: EvidenceEnvironment,
    workspace: InvocationWorkspace,
    executor: E,
    observed_stdout_bytes: usize,
    observed_stderr_bytes: usize,
    driver_request: driver_protocol::DriverRequest,
}

impl<'a, E: SandboxExecutor> PreparedSandbox<'a, E> {
    pub fn prepare(
        request: &'a LowerRequest,
        snapshot: &'a Snapshot,
        candidate: &'a InjectedCandidate,
        private_parent: &Path,
        executor: E,
    ) -> Result<Self, SandboxError> {
        snapshot
            .validate()
            .map_err(|_| SandboxError::SandboxUnavailable)?;
        let validated = candidate.validate_for(request)?;
        let snapshot_handle = snapshot
            .try_clone_root()
            .map_err(|_| SandboxError::SandboxUnavailable)?;
        let environment = EvidenceEnvironment::frozen();
        environment
            .validate()
            .map_err(|_| SandboxError::ToolchainArgument)?;
        let driver_request = driver_protocol::construct_request(
            request,
            snapshot.inputs(),
            candidate.driver_release_identity(),
        )
        .map_err(|error| SandboxError::DriverProtocol(error.code))?;
        let workspace = InvocationWorkspace::create(
            private_parent,
            snapshot.path(),
            &validated.frontend_root,
            &validated.toolchain_root,
            driver_request.transport(),
        )?;
        Ok(Self {
            request,
            snapshot,
            candidate_source: candidate,
            candidate: validated,
            snapshot_handle,
            environment,
            workspace,
            executor,
            observed_stdout_bytes: 0,
            observed_stderr_bytes: 0,
            driver_request,
        })
    }

    pub(crate) fn execute(
        &mut self,
        invocation: &CargoInvocation,
    ) -> Result<ProcessOutput, SandboxError> {
        self.snapshot
            .validate()
            .map_err(|_| SandboxError::SandboxUnavailable)?;
        self.candidate = self.candidate_source.validate_for(self.request)?;
        self.workspace.validate(
            self.snapshot.path(),
            &self.candidate.frontend_root,
            &self.candidate.toolchain_root,
        )?;
        self.workspace.validate_before(invocation.kind())?;
        self.environment
            .validate()
            .map_err(|_| SandboxError::ToolchainArgument)?;
        let stdout_remaining = STDOUT_BYTES_LIMIT
            .checked_sub(self.observed_stdout_bytes)
            .ok_or(SandboxError::ChildOutputLimit)?;
        let stderr_remaining = STDERR_BYTES_LIMIT
            .checked_sub(self.observed_stderr_bytes)
            .ok_or(SandboxError::ChildOutputLimit)?;
        let mut limits = SandboxLimits::FROZEN;
        limits.stdout_bytes = stdout_remaining;
        limits.stderr_bytes = stderr_remaining;
        let context = SandboxContext {
            invocation_id: self.workspace.invocation_id,
            snapshot_root: self.snapshot.path(),
            candidate: &self.candidate,
            workspace: &self.workspace,
            environment: &self.environment,
            limits,
            snapshot_handle: &self.snapshot_handle,
            driver_request: &self.driver_request,
        };
        let output = self.executor.execute(&context, invocation)?;
        self.observed_stdout_bytes = self
            .observed_stdout_bytes
            .checked_add(output.stdout.len())
            .ok_or(SandboxError::ChildOutputLimit)?;
        self.observed_stderr_bytes = self
            .observed_stderr_bytes
            .checked_add(output.stderr_observed_bytes)
            .ok_or(SandboxError::ChildOutputLimit)?;
        if output.exceeded_stream_limit()
            || self.observed_stdout_bytes > STDOUT_BYTES_LIMIT
            || self.observed_stderr_bytes > STDERR_BYTES_LIMIT
        {
            return Err(SandboxError::ChildOutputLimit);
        }
        self.workspace.validate_after(invocation.kind())?;
        Ok(output)
    }

    pub fn environment(&self) -> &EvidenceEnvironment {
        &self.environment
    }

    pub fn invocation_id(&self) -> u64 {
        self.workspace.invocation_id
    }

    pub fn driver_request(&self) -> &driver_protocol::DriverRequest {
        &self.driver_request
    }

    pub fn consume_driver_output(
        &self,
        driver_exit_code: i32,
        signaled: bool,
    ) -> Result<driver_protocol::DriverOutput, driver_protocol::DriverProtocolError> {
        let bytes = crate::driver_process::consume_result_from_open_directory(
            self.workspace.driver_output_handle(),
        )?;
        driver_protocol::parse_output_transport(
            &bytes,
            &self.driver_request,
            driver_exit_code,
            signaled,
        )
    }

    pub(crate) fn consume_driver_output_artifact(
        &self,
    ) -> Result<driver_protocol::DriverOutput, driver_protocol::DriverProtocolError> {
        let bytes = crate::driver_process::consume_result_from_open_directory(
            self.workspace.driver_output_handle(),
        )?;
        driver_protocol::parse_output_artifact(&bytes, &self.driver_request)
    }

    pub(crate) fn driver_output_is_empty(
        &self,
    ) -> Result<bool, driver_protocol::DriverProtocolError> {
        crate::driver_process::open_directory_is_empty(self.workspace.driver_output_handle())
    }

    pub(crate) fn target_id(&self) -> &'static str {
        self.candidate.target.id()
    }

    pub fn into_executor(self) -> E {
        self.executor
    }
}

#[derive(Default)]
pub struct LinuxNamespaceExecutor;

impl SandboxExecutor for LinuxNamespaceExecutor {
    fn execute(
        &mut self,
        context: &SandboxContext<'_>,
        invocation: &CargoInvocation,
    ) -> Result<ProcessOutput, SandboxError> {
        #[cfg(not(target_os = "linux"))]
        {
            let _ = (context, invocation);
            Err(SandboxError::SandboxUnavailable)
        }
        #[cfg(target_os = "linux")]
        {
            execute_linux_namespace(context, invocation)
        }
    }
}

#[cfg(target_os = "linux")]
fn execute_linux_namespace(
    context: &SandboxContext<'_>,
    invocation: &CargoInvocation,
) -> Result<ProcessOutput, SandboxError> {
    use std::os::unix::process::{CommandExt, ExitStatusExt};

    context
        .workspace
        .validate_resource_filesystem(context.limits())?;
    let retained_descriptors = context.retained_descriptors();
    let retained_sources = [
        retained_fd_path(retained_descriptors[0]),
        retained_fd_path(retained_descriptors[2]),
        retained_fd_path(retained_descriptors[1]),
        retained_fd_path(retained_descriptors[3]),
        retained_fd_path(retained_descriptors[4]),
        retained_fd_path(retained_descriptors[5]),
        retained_fd_path(retained_descriptors[6]),
        retained_fd_path(retained_descriptors[7]),
        retained_fd_path(retained_descriptors[8]),
        retained_fd_path(retained_descriptors[9]),
        retained_fd_path(retained_descriptors[10]),
    ];
    if !context.rootfs().is_absolute() || context.rootfs().to_str().is_none() {
        return Err(SandboxError::SandboxUnavailable);
    }

    let bootstrap = if OUTER_SANDBOX_ACTIVE.load(Ordering::Acquire) {
        "__rust2vir_cargo_outer_sandbox_v0"
    } else {
        "__rust2vir_cargo_sandbox_v0"
    };
    let mut arguments = vec![
        bootstrap.to_owned(),
        context
            .rootfs()
            .to_str()
            .ok_or(SandboxError::SandboxUnavailable)?
            .to_owned(),
    ];
    arguments.extend(retained_sources.iter().map(|path| path.to_owned()));
    arguments.push("--".to_owned());
    arguments.extend(invocation.arguments().iter().cloned());

    let bootstrap_loader = format!("{}/lib64/ld-linux-x86-64.so.2", retained_sources[3]);
    let bootstrap_library_path = format!("{}/lib/x86_64-linux-gnu", retained_sources[3]);
    let bootstrap_executable = format!("{}/bin/rust2vir", retained_sources[2]);
    let mut command = Command::new(bootstrap_loader);
    command
        .arg("--library-path")
        .arg(bootstrap_library_path)
        .arg(bootstrap_executable)
        .args(arguments)
        .env_clear()
        .envs(context.environment().entries())
        .current_dir(&context.workspace.root)
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .process_group(0);
    // SAFETY: the callback performs only fcntl on already-open descriptors. It neither
    // allocates nor touches shared application state between fork and exec.
    unsafe {
        command.pre_exec(move || {
            for descriptor in retained_descriptors.iter().copied() {
                linux::inherit_descriptor(descriptor)?;
            }
            Ok(())
        });
    }
    let mut child = command
        .spawn()
        .map_err(|_| SandboxError::SandboxUnavailable)?;
    let child_id = child.id();
    let stdout = child.stdout.take().ok_or(SandboxError::Spawn)?;
    let stderr = child.stderr.take().ok_or(SandboxError::Spawn)?;
    let overflow = Arc::new(AtomicBool::new(false));
    let read_failed = Arc::new(AtomicBool::new(false));
    let stdout_reader = bounded_reader(
        stdout,
        context.limits().stdout_bytes,
        true,
        Arc::clone(&overflow),
        Arc::clone(&read_failed),
    );
    let stderr_reader = bounded_reader(
        stderr,
        context.limits().stderr_bytes,
        false,
        Arc::clone(&overflow),
        Arc::clone(&read_failed),
    );
    let deadline = Instant::now()
        .checked_add(CHILD_WALL_CLOCK_TIMEOUT)
        .ok_or(SandboxError::Killed)?;
    let mut timed_out = false;
    let status = loop {
        if overflow.load(Ordering::Acquire) {
            kill_process_group(child_id);
            let _ = child.kill();
        } else if Instant::now() >= deadline {
            timed_out = true;
            kill_process_group(child_id);
            let _ = child.kill();
        }
        match child.try_wait() {
            Ok(Some(status)) => break status,
            Ok(None) => thread::yield_now(),
            Err(_) => {
                kill_process_group(child_id);
                let _ = child.kill();
                let _ = child.wait();
                return Err(SandboxError::Killed);
            }
        }
    };
    kill_process_group(child_id);
    let (stdout, stdout_observed) = stdout_reader.join().map_err(|_| SandboxError::Killed)?;
    let (_, stderr_observed) = stderr_reader.join().map_err(|_| SandboxError::Killed)?;
    let stream_limit = overflow.load(Ordering::Acquire);
    if !stream_limit && timed_out {
        return Err(SandboxError::Killed);
    }
    if !stream_limit && read_failed.load(Ordering::Acquire) {
        return Err(SandboxError::Killed);
    }
    if status.code() == Some(125) {
        return Err(SandboxError::SandboxUnavailable);
    }
    if status.code() == Some(126) {
        return Err(SandboxError::SandboxUnavailable);
    }
    Ok(ProcessOutput {
        exit_code: status.code(),
        signaled: status.signal().is_some(),
        stdout,
        stderr_observed_bytes: stderr_observed,
        stdout_limit_exceeded: stdout_observed > context.limits().stdout_bytes,
        stderr_limit_exceeded: stderr_observed > context.limits().stderr_bytes,
    })
}

#[cfg(target_os = "linux")]
fn retained_fd_path(descriptor: i32) -> String {
    format!("/proc/self/fd/{descriptor}")
}

#[cfg(target_os = "linux")]
fn bounded_reader<R: Read + Send + 'static>(
    mut reader: R,
    maximum: usize,
    retain: bool,
    overflow: Arc<AtomicBool>,
    read_failed: Arc<AtomicBool>,
) -> thread::JoinHandle<(Vec<u8>, usize)> {
    thread::spawn(move || {
        let mut retained = Vec::new();
        let mut observed = 0_usize;
        let retention_limit = maximum.checked_add(1).unwrap_or_else(|| {
            overflow.store(true, Ordering::Release);
            maximum
        });
        let mut buffer = [0_u8; 16 * 1024];
        loop {
            match reader.read(&mut buffer) {
                Ok(0) => break,
                Err(_) => {
                    read_failed.store(true, Ordering::Release);
                    break;
                }
                Ok(count) => {
                    observed = match observed.checked_add(count) {
                        Some(observed) => observed,
                        None => {
                            overflow.store(true, Ordering::Release);
                            usize::MAX
                        }
                    };
                    if observed > maximum {
                        overflow.store(true, Ordering::Release);
                    }
                    if retain && retained.len() <= maximum {
                        let remaining = retention_limit.saturating_sub(retained.len());
                        retained.extend_from_slice(&buffer[..count.min(remaining)]);
                    }
                }
            }
        }
        (retained, observed)
    })
}

#[cfg(target_os = "linux")]
fn kill_process_group(process: u32) {
    if let Ok(process) = i32::try_from(process) {
        // SAFETY: a negative, validated child process-group ID and SIGKILL contain no pointers.
        let _ = unsafe { linux::kill(-process, linux::SIGKILL) };
    }
}

pub fn run_bootstrap(arguments: &[String]) -> u8 {
    #[cfg(not(target_os = "linux"))]
    {
        let _ = arguments;
        125
    }
    #[cfg(target_os = "linux")]
    {
        linux_bootstrap(arguments, false).unwrap_or_else(|code| code)
    }
}

pub fn run_outer_bootstrap(arguments: &[String]) -> u8 {
    #[cfg(not(target_os = "linux"))]
    {
        let _ = arguments;
        125
    }
    #[cfg(target_os = "linux")]
    {
        linux_bootstrap(arguments, true).unwrap_or_else(|code| code)
    }
}

pub fn mount_outer_proc() -> u8 {
    #[cfg(not(target_os = "linux"))]
    {
        125
    }
    #[cfg(target_os = "linux")]
    {
        linux::mount_outer_proc(Path::new("/proc")).map_or_else(
            |code| code,
            |()| {
                OUTER_SANDBOX_ACTIVE.store(true, Ordering::Release);
                0
            },
        )
    }
}

#[cfg(target_os = "linux")]
fn linux_bootstrap(arguments: &[String], inherited_user_namespace: bool) -> Result<u8, u8> {
    use std::os::unix::ffi::OsStrExt;
    use std::os::unix::process::ExitStatusExt;

    if arguments.len() < 14 || arguments[12] != "--" {
        return Err(125);
    }
    let paths = arguments[..12]
        .iter()
        .map(PathBuf::from)
        .collect::<Vec<_>>();
    if paths
        .iter()
        .any(|path| !path.is_absolute() || path.as_os_str().as_bytes().contains(&0))
        || arguments[13..]
            .iter()
            .any(|argument| argument.is_empty() || argument.contains('\0'))
        || current_environment() != EvidenceEnvironment::frozen().entries().clone()
    {
        return Err(125);
    }
    let [rootfs, input, toolchain, frontend, native_runtime, work, home, cargo_home, temporary, target, driver_output, driver_request]: [&Path; 12] =
        paths.iter().map(PathBuf::as_path).collect::<Vec<_>>().try_into().map_err(|_| 125)?;

    if inherited_user_namespace {
        linux::enter_outer_namespaces()?;
    } else {
        linux::enter_namespaces()?;
    }
    linux::bind_root(rootfs)?;
    let frontend_bin = frontend.join("bin");
    for (source, destination, executable) in [
        (input, "mpk/input", false),
        (toolchain, "mpk/toolchain", true),
        (frontend_bin.as_path(), "mpk/frontend", true),
        (work, "mpk/work", false),
        (native_runtime, "mpk/native-runtime", true),
        (
            &native_runtime.join("lib/x86_64-linux-gnu"),
            "lib/x86_64-linux-gnu",
            true,
        ),
    ] {
        linux::bind_view(source, &rootfs.join(destination), true, executable)?;
    }
    linux::bind_view(
        &native_runtime.join("lib64/ld-linux-x86-64.so.2"),
        &rootfs.join("lib64/ld-linux-x86-64.so.2"),
        true,
        true,
    )?;
    linux::bind_view(
        driver_request,
        &rootfs.join("mpk/driver-request.json"),
        true,
        false,
    )?;
    for (source, (destination, executable)) in [home, cargo_home, temporary, target, driver_output]
        .into_iter()
        .zip(fixed_writable_mount_views())
    {
        let destination = destination.strip_prefix('/').ok_or(125)?;
        linux::bind_view(source, &rootfs.join(destination), false, executable)?;
    }
    linux::mount_null(&rootfs.join("dev/null"))?;
    if let Some(status) = linux::fork_pid_namespace()? {
        return Ok(status);
    }
    linux::mount_proc(&rootfs.join("proc"))?;
    linux::seal_root(rootfs)?;
    linux::enter_root(rootfs)?;
    linux::apply_process_controls()?;
    for source in &paths[1..] {
        linux::close_retained_path(source)?;
    }

    let environment = EvidenceEnvironment::frozen();
    linux::drop_and_lock_capabilities()?;
    let status = Command::new(CARGO_PATH)
        .args(&arguments[13..])
        .env_clear()
        .envs(environment.entries())
        .current_dir(WORK_ROOT)
        .stdin(Stdio::null())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit())
        .status()
        .map_err(|_| 126)?;
    if status.signal().is_some() {
        return Err(125);
    }
    status
        .code()
        .and_then(|code| u8::try_from(code).ok())
        .ok_or(125)
}

#[cfg(target_os = "linux")]
fn current_environment() -> BTreeMap<String, String> {
    std::env::vars().collect()
}

#[cfg(target_os = "linux")]
mod linux {
    use super::{
        validate_resource_filesystem_observation, ResourceFilesystemObservation, SandboxLimits,
        OPEN_FILE_LIMIT, VIRTUAL_MEMORY_LIMIT,
    };
    use std::ffi::{c_char, c_int, c_long, c_ulong, c_void, CString};
    use std::fs;
    use std::io::Read;
    use std::os::fd::AsRawFd;
    use std::os::unix::ffi::OsStrExt;
    use std::os::unix::fs::{FileTypeExt, MetadataExt, OpenOptionsExt};
    use std::path::{Component, Path, PathBuf};

    pub(super) const SIGKILL: c_int = 9;
    const CLONE_NEWNS: c_int = 0x0002_0000;
    const CLONE_NEWUTS: c_int = 0x0400_0000;
    const CLONE_NEWIPC: c_int = 0x0800_0000;
    const CLONE_NEWUSER: c_int = 0x1000_0000;
    const CLONE_NEWPID: c_int = 0x2000_0000;
    const CLONE_NEWNET: c_int = 0x4000_0000;
    const MS_RDONLY: c_ulong = 1;
    const MS_NOSUID: c_ulong = 2;
    const MS_NODEV: c_ulong = 4;
    const MS_NOEXEC: c_ulong = 8;
    const MS_REMOUNT: c_ulong = 32;
    const MS_BIND: c_ulong = 4_096;
    const MS_REC: c_ulong = 16_384;
    const MS_PRIVATE: c_ulong = 1 << 18;
    const PR_CAPBSET_DROP: c_int = 24;
    const PR_GET_SECUREBITS: c_int = 27;
    const PR_SET_SECUREBITS: c_int = 28;
    const PR_SET_NO_NEW_PRIVS: c_int = 38;
    const PR_GET_NO_NEW_PRIVS: c_int = 39;
    const PR_CAP_AMBIENT: c_int = 47;
    const PR_CAP_AMBIENT_CLEAR_ALL: c_ulong = 4;
    const PRCTL_ZERO: c_ulong = 0;
    const PRCTL_ONE: c_ulong = 1;
    const SECBIT_NOROOT: c_ulong = 1 << 0;
    const SECBIT_NOROOT_LOCKED: c_ulong = 1 << 1;
    const SECBIT_NO_SETUID_FIXUP: c_ulong = 1 << 2;
    const SECBIT_NO_SETUID_FIXUP_LOCKED: c_ulong = 1 << 3;
    const SECBIT_KEEP_CAPS_LOCKED: c_ulong = 1 << 5;
    const SECBIT_NO_CAP_AMBIENT_RAISE: c_ulong = 1 << 6;
    const SECBIT_NO_CAP_AMBIENT_RAISE_LOCKED: c_ulong = 1 << 7;
    const LOCKED_NO_CAPABILITIES_SECUREBITS: c_ulong = SECBIT_NOROOT
        | SECBIT_NOROOT_LOCKED
        | SECBIT_NO_SETUID_FIXUP
        | SECBIT_NO_SETUID_FIXUP_LOCKED
        | SECBIT_KEEP_CAPS_LOCKED
        | SECBIT_NO_CAP_AMBIENT_RAISE
        | SECBIT_NO_CAP_AMBIENT_RAISE_LOCKED;
    const LINUX_CAPABILITY_VERSION_3: u32 = 0x2008_0522;
    const ST_NOSUID: c_long = 2;
    const ST_NODEV: c_long = 4;
    const RLIMIT_FSIZE: c_int = 1;
    const RLIMIT_CORE: c_int = 4;
    const RLIMIT_NPROC: c_int = 6;
    const RLIMIT_NOFILE: c_int = 7;
    const RLIMIT_AS: c_int = 9;
    const RLIM_INFINITY: u64 = u64::MAX;

    #[repr(C)]
    struct RLimit {
        current: u64,
        maximum: u64,
    }

    #[repr(C)]
    struct CapabilityHeader {
        version: u32,
        pid: c_int,
    }

    #[derive(Clone, Copy)]
    #[repr(C)]
    struct CapabilityData {
        effective: u32,
        permitted: u32,
        inheritable: u32,
    }

    #[repr(C)]
    struct StatFs {
        filesystem_type: c_long,
        block_size: c_long,
        blocks: u64,
        blocks_free: u64,
        blocks_available: u64,
        files: u64,
        files_free: u64,
        filesystem_id: [c_int; 2],
        name_length: c_long,
        fragment_size: c_long,
        flags: c_long,
        spare: [c_long; 4],
    }

    unsafe extern "C" {
        fn capset(header: *mut CapabilityHeader, data: *const CapabilityData) -> c_int;
        fn chroot(path: *const c_char) -> c_int;
        fn close(descriptor: c_int) -> c_int;
        fn fcntl(fd: c_int, command: c_int, ...) -> c_int;
        fn fstatfs(fd: c_int, buffer: *mut StatFs) -> c_int;
        fn fork() -> c_int;
        fn getgid() -> u32;
        fn getpid() -> c_int;
        fn getppid() -> c_int;
        fn getuid() -> u32;
        pub(super) fn kill(pid: c_int, signal: c_int) -> c_int;
        fn mount(
            source: *const c_char,
            target: *const c_char,
            filesystem_type: *const c_char,
            flags: c_ulong,
            data: *const c_void,
        ) -> c_int;
        fn prctl(option: c_int, ...) -> c_int;
        fn sethostname(name: *const c_char, length: usize) -> c_int;
        fn getrlimit(resource: c_int, limit: *mut RLimit) -> c_int;
        fn setrlimit(resource: c_int, limit: *const RLimit) -> c_int;
        fn umask(mask: u32) -> u32;
        fn unshare(flags: c_int) -> c_int;
        fn waitpid(pid: c_int, status: *mut c_int, options: c_int) -> c_int;
    }

    pub(super) fn inherit_descriptor(descriptor: c_int) -> std::io::Result<()> {
        const F_SETFD: c_int = 2;
        // SAFETY: descriptor is retained by SandboxContext and F_SETFD with value zero clears
        // only its close-on-exec flag in the post-fork child.
        if unsafe { fcntl(descriptor, F_SETFD, 0) } == -1 {
            return Err(std::io::Error::last_os_error());
        }
        Ok(())
    }

    pub(super) fn close_retained_path(path: &Path) -> Result<(), u8> {
        let descriptor = path
            .file_name()
            .and_then(|name| name.to_str())
            .and_then(|name| name.parse::<c_int>().ok())
            .ok_or(125)?;
        // SAFETY: the descriptor number came from the trusted retained /proc/self/fd path and
        // is closed only after all bind mounts have completed.
        if unsafe { close(descriptor) } != 0 {
            return Err(125);
        }
        Ok(())
    }

    pub(super) fn enter_namespaces() -> Result<(), u8> {
        // SAFETY: getuid/getgid take no arguments and have no memory preconditions. Capture the
        // host identities before entering the user namespace, where they are not yet mapped.
        let uid = unsafe { getuid() };
        let gid = unsafe { getgid() };
        // SAFETY: unshare receives a constant flag mask and changes only the calling process.
        if unsafe { unshare(CLONE_NEWUSER) } != 0 {
            return Err(125);
        }
        fs::write("/proc/self/setgroups", b"deny\n").map_err(|_| 125)?;
        fs::write("/proc/self/uid_map", format!("0 {uid} 1\n")).map_err(|_| 125)?;
        fs::write("/proc/self/gid_map", format!("0 {gid} 1\n")).map_err(|_| 125)?;
        let flags = CLONE_NEWNS | CLONE_NEWNET | CLONE_NEWIPC | CLONE_NEWUTS;
        // SAFETY: unshare receives the closed namespace mask and changes only this process.
        if unsafe { unshare(flags) } != 0 {
            return Err(125);
        }
        mount_call(None, Path::new("/"), MS_REC | MS_PRIVATE)?;
        let hostname = b"mpk-rust";
        // SAFETY: the byte slice is valid for its supplied length.
        if unsafe { sethostname(hostname.as_ptr().cast(), hostname.len()) } != 0 {
            return Err(125);
        }
        Ok(())
    }

    pub(super) fn enter_outer_namespaces() -> Result<(), u8> {
        const PR_GET_NO_NEW_PRIVS: c_int = 39;
        // The outer bootstrap executes the frontend as PID 1 after entering its user namespace.
        // This child may reuse that user namespace only when the verified namespace-init parent
        // and no-new-privileges state are both still present.
        if unsafe { getuid() } != 0
            || unsafe { getgid() } != 0
            || unsafe { getppid() } != 1
            || unsafe { prctl(PR_GET_NO_NEW_PRIVS, 0, 0, 0, 0) } != 1
        {
            return Err(125);
        }
        let flags = CLONE_NEWNS | CLONE_NEWNET | CLONE_NEWIPC | CLONE_NEWUTS;
        // SAFETY: the outer bootstrap retained the capabilities of its private user namespace;
        // unshare receives only the closed non-user namespace mask.
        if unsafe { unshare(flags) } != 0 {
            return Err(125);
        }
        mount_call(None, Path::new("/"), MS_REC | MS_PRIVATE)?;
        let hostname = b"mpk-rust";
        // SAFETY: the byte slice is valid for its supplied length.
        if unsafe { sethostname(hostname.as_ptr().cast(), hostname.len()) } != 0 {
            return Err(125);
        }
        Ok(())
    }

    pub(super) fn fork_pid_namespace() -> Result<Option<u8>, u8> {
        // Delay PID isolation until retained /proc/self/fd paths have been mounted. The forked
        // child becomes PID 1, mounts the namespace-local procfs, and supervises Cargo.
        if unsafe { unshare(CLONE_NEWPID) } != 0 {
            return Err(125);
        }
        // SAFETY: the bootstrap is single-threaded and immediately branches without accessing
        // shared application state. Both processes retain the already-prepared mount namespace.
        let child = unsafe { fork() };
        if child < 0 {
            return Err(125);
        }
        if child == 0 {
            return Ok(None);
        }
        let mut status = 0;
        // SAFETY: child is the exact positive PID returned by fork and status is writable.
        if unsafe { waitpid(child, &mut status, 0) } != child || status & 0x7f != 0 {
            return Err(125);
        }
        Ok(Some(((status >> 8) & 0xff) as u8))
    }

    pub(super) fn mount_proc(target: &Path) -> Result<(), u8> {
        let source = c"proc";
        let filesystem = c"proc";
        let target = path_cstring(target)?;
        // SAFETY: all strings are live NUL-terminated values and procfs accepts null data.
        if unsafe {
            mount(
                source.as_ptr(),
                target.as_ptr(),
                filesystem.as_ptr(),
                MS_NOSUID | MS_NODEV | MS_NOEXEC,
                std::ptr::null(),
            )
        } != 0
        {
            return Err(125);
        }
        Ok(())
    }

    pub(super) fn mount_outer_proc(target: &Path) -> Result<(), u8> {
        // The outer launcher creates the frontend as the first CLONE_NEWPID child. Refuse the
        // internal bootstrap token anywhere except that namespace-init position.
        // SAFETY: getpid takes no arguments and has no memory preconditions.
        if unsafe { getpid() } != 1 {
            return Err(125);
        }
        mount_proc(target)
    }

    pub(super) fn mount_null(target: &Path) -> Result<(), u8> {
        let mut options = fs::OpenOptions::new();
        let retained = options
            .read(true)
            .write(true)
            .custom_flags(0o400_000 | 0o2_000_000)
            .open("/dev/null")
            .map_err(|_| 125)?;
        let before = retained.metadata().map_err(|_| 125)?;
        if !before.file_type().is_char_device() || before.rdev() != 259 {
            return Err(125);
        }
        mount_call(Some(Path::new("/dev/null")), target, MS_BIND)?;
        let mounted = fs::metadata(target).map_err(|_| 125)?;
        let named = fs::metadata("/dev/null").map_err(|_| 125)?;
        if !same_node(&before, &mounted) || !same_node(&before, &named) {
            return Err(125);
        }
        mount_call(None, target, MS_BIND | MS_REMOUNT | MS_NOSUID | MS_NOEXEC)?;
        if !same_node(&before, &fs::metadata(target).map_err(|_| 125)?) {
            return Err(125);
        }
        Ok(())
    }

    pub(super) fn bind_root(root: &Path) -> Result<(), u8> {
        mount_call(Some(root), root, MS_BIND | MS_REC)
    }

    pub(super) fn bind_view(
        source: &Path,
        target: &Path,
        read_only: bool,
        executable: bool,
    ) -> Result<(), u8> {
        let before = fs::metadata(source).map_err(|_| 125)?;
        let named_source = retained_named_path(source, &before)?;
        mount_call(Some(&named_source), target, MS_BIND)?;
        let mounted = fs::metadata(target).map_err(|_| 125)?;
        let after = fs::metadata(source).map_err(|_| 125)?;
        if !same_node(&before, &mounted) || !same_node(&before, &after) {
            return Err(125);
        }
        let mut flags = MS_BIND | MS_REMOUNT | MS_NOSUID | MS_NODEV;
        if read_only {
            flags |= MS_RDONLY;
        }
        if !executable {
            flags |= MS_NOEXEC;
        }
        mount_call(None, target, flags)?;
        if !same_node(&before, &fs::metadata(target).map_err(|_| 125)?) {
            return Err(125);
        }
        Ok(())
    }

    fn retained_named_path(source: &Path, expected: &fs::Metadata) -> Result<PathBuf, u8> {
        let relative = source.strip_prefix("/proc/self/fd").map_err(|_| 125)?;
        let mut components = relative.components();
        let descriptor = match components.next() {
            Some(Component::Normal(value))
                if value
                    .to_str()
                    .and_then(|value| value.parse::<c_int>().ok())
                    .is_some() =>
            {
                value
            }
            _ => return Err(125),
        };
        let mut named =
            fs::read_link(Path::new("/proc/self/fd").join(descriptor)).map_err(|_| 125)?;
        if !named.is_absolute() {
            return Err(125);
        }
        for component in components {
            match component {
                Component::Normal(value) => named.push(value),
                _ => return Err(125),
            }
        }
        let names = named
            .components()
            .filter_map(|component| match component {
                Component::RootDir => None,
                Component::Normal(value) => Some(Ok(value.to_owned())),
                _ => Some(Err(125)),
            })
            .collect::<Result<Vec<_>, _>>()?;
        for start in 0..names.len() {
            let mut candidate = PathBuf::from("/");
            candidate.extend(&names[start..]);
            let Ok(metadata) = fs::symlink_metadata(&candidate) else {
                continue;
            };
            if !metadata.file_type().is_symlink()
                && (metadata.is_dir() || metadata.is_file())
                && same_node(expected, &metadata)
            {
                return Ok(candidate);
            }
        }
        Err(125)
    }

    fn same_node(left: &fs::Metadata, right: &fs::Metadata) -> bool {
        const S_IFMT: u32 = 0o170_000;
        left.dev() == right.dev()
            && left.ino() == right.ino()
            && left.mode() & S_IFMT == right.mode() & S_IFMT
    }

    pub(super) fn seal_root(root: &Path) -> Result<(), u8> {
        mount_call(
            None,
            root,
            MS_BIND | MS_REMOUNT | MS_RDONLY | MS_NOSUID | MS_NODEV | MS_NOEXEC,
        )
    }

    pub(super) fn enter_root(root: &Path) -> Result<(), u8> {
        let root = path_cstring(root)?;
        // SAFETY: root is a NUL-terminated absolute path prepared by the trusted parent.
        if unsafe { chroot(root.as_ptr()) } != 0 {
            return Err(125);
        }
        std::env::set_current_dir("/").map_err(|_| 125)
    }

    pub(super) fn apply_process_controls() -> Result<(), u8> {
        for (resource, value) in process_limit_settings() {
            let limit = RLimit {
                current: value,
                maximum: value,
            };
            // SAFETY: limit points to a fully initialized Linux rlimit structure.
            if unsafe { setrlimit(resource, &limit) } != 0 {
                return Err(125);
            }
        }
        for (resource, expected) in process_limit_settings() {
            let mut observed = RLimit {
                current: 0,
                maximum: 0,
            };
            // SAFETY: observed points to writable storage for one Linux rlimit structure.
            if unsafe { getrlimit(resource, &mut observed) } != 0
                || observed.current != expected
                || observed.maximum != expected
            {
                return Err(125);
            }
        }
        // SAFETY: PR_SET_NO_NEW_PRIVS has the fixed integer arguments required by Linux.
        if unsafe {
            prctl(
                PR_SET_NO_NEW_PRIVS,
                PRCTL_ONE,
                PRCTL_ZERO,
                PRCTL_ZERO,
                PRCTL_ZERO,
            )
        } != 0
        {
            return Err(125);
        }
        // SAFETY: umask accepts only permission bits and has no pointer arguments.
        unsafe { umask(0o077) };
        Ok(())
    }

    fn process_limit_settings() -> [(c_int, u64); 5] {
        [
            (RLIMIT_FSIZE, RLIM_INFINITY),
            (RLIMIT_NPROC, RLIM_INFINITY),
            (RLIMIT_CORE, 0),
            (RLIMIT_NOFILE, OPEN_FILE_LIMIT),
            (RLIMIT_AS, VIRTUAL_MEMORY_LIMIT),
        ]
    }

    pub(super) fn drop_and_lock_capabilities() -> Result<(), u8> {
        let capability_last = parse_capability_last(&read_bounded_text(
            Path::new("/proc/sys/kernel/cap_last_cap"),
            32,
        )?)
        .ok_or(125)?;

        // Securebits and the bounding set can be changed only while CAP_SETPCAP is effective.
        // Disable root and set-ID capability recovery, lock keep-caps off, and forbid ambient
        // raises before clearing the final effective and permitted capability sets.
        // SAFETY: every prctl operation uses its documented fixed scalar argument layout.
        if unsafe {
            prctl(
                PR_SET_SECUREBITS,
                LOCKED_NO_CAPABILITIES_SECUREBITS,
                PRCTL_ZERO,
                PRCTL_ZERO,
                PRCTL_ZERO,
            )
        } != 0
            || unsafe {
                prctl(
                    PR_CAP_AMBIENT,
                    PR_CAP_AMBIENT_CLEAR_ALL,
                    PRCTL_ZERO,
                    PRCTL_ZERO,
                    PRCTL_ZERO,
                )
            } != 0
        {
            return Err(125);
        }
        for capability in 0..=capability_last {
            // SAFETY: capability_last was read from the namespace-local kernel capability ABI.
            if unsafe {
                prctl(
                    PR_CAPBSET_DROP,
                    c_ulong::from(capability),
                    PRCTL_ZERO,
                    PRCTL_ZERO,
                    PRCTL_ZERO,
                )
            } != 0
            {
                return Err(125);
            }
        }

        let mut header = CapabilityHeader {
            version: LINUX_CAPABILITY_VERSION_3,
            pid: 0,
        };
        let empty = [CapabilityData {
            effective: 0,
            permitted: 0,
            inheritable: 0,
        }; 2];
        // SAFETY: version 3 consumes exactly two initialized capability data records for the
        // calling thread (pid zero). The pointers remain valid for the duration of the call.
        if unsafe { capset(&mut header, empty.as_ptr()) } != 0 {
            return Err(125);
        }

        // Verify both the irreversible locks and the procfs representation inherited by Cargo.
        // SAFETY: these prctl getters use zero scalar arguments and do not dereference pointers.
        if unsafe {
            prctl(
                PR_GET_SECUREBITS,
                PRCTL_ZERO,
                PRCTL_ZERO,
                PRCTL_ZERO,
                PRCTL_ZERO,
            )
        } != LOCKED_NO_CAPABILITIES_SECUREBITS as c_int
            || unsafe {
                prctl(
                    PR_GET_NO_NEW_PRIVS,
                    PRCTL_ZERO,
                    PRCTL_ZERO,
                    PRCTL_ZERO,
                    PRCTL_ZERO,
                )
            } != 1
        {
            return Err(125);
        }
        let status = read_bounded_text(Path::new("/proc/self/status"), 1 << 20)?;
        if !capability_status_is_locked(&status) {
            return Err(125);
        }
        Ok(())
    }

    fn read_bounded_text(path: &Path, maximum: usize) -> Result<String, u8> {
        let maximum_plus_one = maximum.checked_add(1).ok_or(125)?;
        let mut bytes = Vec::with_capacity(maximum_plus_one);
        fs::File::open(path)
            .map_err(|_| 125)?
            .take(maximum_plus_one as u64)
            .read_to_end(&mut bytes)
            .map_err(|_| 125)?;
        if bytes.len() > maximum {
            return Err(125);
        }
        String::from_utf8(bytes).map_err(|_| 125)
    }

    fn parse_capability_last(value: &str) -> Option<u32> {
        let digits = value.strip_suffix('\n')?;
        if digits.is_empty() || !digits.bytes().all(|byte| byte.is_ascii_digit()) {
            return None;
        }
        let capability = digits.parse::<u32>().ok()?;
        (capability < 64).then_some(capability)
    }

    fn capability_status_is_locked(status: &str) -> bool {
        const REQUIRED_CAPABILITIES: [(&str, u8); 5] = [
            ("CapInh", 1 << 0),
            ("CapPrm", 1 << 1),
            ("CapEff", 1 << 2),
            ("CapBnd", 1 << 3),
            ("CapAmb", 1 << 4),
        ];

        let mut capability_names = Vec::new();
        let mut required_seen = 0_u8;
        let mut no_new_privileges_seen = false;
        for line in status.lines() {
            if line.starts_with("Cap") {
                let Some((name, value)) = line.split_once(':') else {
                    return false;
                };
                if capability_names.contains(&name) {
                    return false;
                }
                capability_names.push(name);
                let value = value.trim();
                if value.is_empty()
                    || !value.bytes().all(|byte| byte.is_ascii_hexdigit())
                    || !value.bytes().all(|byte| byte == b'0')
                {
                    return false;
                }
                if let Some((_, bit)) = REQUIRED_CAPABILITIES
                    .iter()
                    .find(|(required, _)| name == *required)
                {
                    required_seen |= bit;
                }
            } else if line.starts_with("NoNewPrivs") {
                let Some((name, value)) = line.split_once(':') else {
                    return false;
                };
                if name != "NoNewPrivs" || no_new_privileges_seen || value.trim() != "1" {
                    return false;
                }
                no_new_privileges_seen = true;
            }
        }
        required_seen == (1 << REQUIRED_CAPABILITIES.len()) - 1 && no_new_privileges_seen
    }

    pub(super) fn validate_resource_filesystem(
        root: &Path,
        writable: &[&Path],
        limits: SandboxLimits,
    ) -> Result<(), u8> {
        let root_metadata = fs::symlink_metadata(root).map_err(|_| 125)?;
        if !root_metadata.is_dir() || root_metadata.file_type().is_symlink() {
            return Err(125);
        }
        let mut same_device = true;
        for path in writable {
            let metadata = fs::symlink_metadata(path).map_err(|_| 125)?;
            if !metadata.is_dir() || metadata.file_type().is_symlink() {
                return Err(125);
            }
            same_device &= metadata.dev() == root_metadata.dev();
        }
        let directory = fs::File::open(root).map_err(|_| 125)?;
        let mut information = StatFs {
            filesystem_type: 0,
            block_size: 0,
            blocks: 0,
            blocks_free: 0,
            blocks_available: 0,
            files: 0,
            files_free: 0,
            filesystem_id: [0; 2],
            name_length: 0,
            fragment_size: 0,
            flags: 0,
            spare: [0; 4],
        };
        // SAFETY: information is a writable Linux statfs structure and directory remains open.
        if unsafe { fstatfs(directory.as_raw_fd(), &mut information) } != 0 {
            return Err(125);
        }
        let fragment_size = u64::try_from(information.fragment_size).map_err(|_| 125)?;
        let allocated_bytes = information.blocks.checked_mul(fragment_size).ok_or(125)?;
        validate_resource_filesystem_observation(
            ResourceFilesystemObservation {
                filesystem_type: information.filesystem_type as u64,
                allocated_capacity_bytes: allocated_bytes,
                inode_capacity: information.files,
                same_device,
                nosuid: information.flags & ST_NOSUID != 0,
                nodev: information.flags & ST_NODEV != 0,
                noswap: mountinfo_has_noswap(root)?,
            },
            limits,
        )
        .map_err(|_| 125)
    }

    fn mountinfo_has_noswap(root: &Path) -> Result<bool, u8> {
        let root = root.to_str().ok_or(125)?;
        if root.contains([' ', '\\']) {
            return Err(125);
        }
        let mountinfo = read_bounded_text(Path::new("/proc/self/mountinfo"), 16 * 1024 * 1024)?;
        let mut selected: Option<(&str, &str, &str)> = None;
        for line in mountinfo.lines() {
            let (mount_fields, filesystem_fields) = line.split_once(" - ").ok_or(125)?;
            let mount_fields = mount_fields.split_ascii_whitespace().collect::<Vec<_>>();
            let filesystem_fields = filesystem_fields
                .split_ascii_whitespace()
                .collect::<Vec<_>>();
            if mount_fields.len() < 6 || filesystem_fields.len() < 3 {
                return Err(125);
            }
            let mountpoint = mount_fields[4];
            let contains_root = root == mountpoint
                || root
                    .strip_prefix(mountpoint)
                    .is_some_and(|suffix| suffix.starts_with('/'));
            if contains_root
                && selected.is_none_or(|(current, _, _)| mountpoint.len() > current.len())
            {
                selected = Some((mountpoint, mount_fields[5], filesystem_fields[2]));
                if filesystem_fields[0] != "tmpfs" {
                    selected = Some((mountpoint, "", ""));
                }
            }
        }
        let Some((_, mount_options, super_options)) = selected else {
            return Err(125);
        };
        let mount_options = mount_options
            .split(',')
            .collect::<std::collections::BTreeSet<_>>();
        let super_options = super_options
            .split(',')
            .collect::<std::collections::BTreeSet<_>>();
        Ok(["rw", "nosuid", "nodev"]
            .into_iter()
            .all(|option| mount_options.contains(option))
            && super_options.contains("noswap"))
    }

    fn mount_call(source: Option<&Path>, target: &Path, flags: c_ulong) -> Result<(), u8> {
        let source = source.map(path_cstring).transpose()?;
        let target = path_cstring(target)?;
        let source_pointer = source
            .as_ref()
            .map_or(std::ptr::null(), |path| path.as_ptr());
        // SAFETY: optional source and required target are live NUL-terminated strings; no
        // filesystem type or data is used for bind/remount/propagation operations.
        if unsafe {
            mount(
                source_pointer,
                target.as_ptr(),
                std::ptr::null(),
                flags,
                std::ptr::null(),
            )
        } != 0
        {
            return Err(125);
        }
        Ok(())
    }

    fn path_cstring(path: &Path) -> Result<CString, u8> {
        CString::new(path.as_os_str().as_bytes()).map_err(|_| 125)
    }

    #[cfg(test)]
    mod tests {
        use super::*;

        const LOCKED_STATUS: &str = concat!(
            "Name:\trust2vir\n",
            "CapInh:\t0000000000000000\n",
            "CapPrm:\t0000000000000000\n",
            "CapEff:\t0000000000000000\n",
            "CapBnd:\t0000000000000000\n",
            "CapAmb:\t0000000000000000\n",
            "NoNewPrivs:\t1\n",
        );

        #[test]
        fn process_limit_profile_removes_competing_limits_and_keeps_exact_limits() {
            assert_eq!(
                process_limit_settings(),
                [
                    (RLIMIT_FSIZE, u64::MAX),
                    (RLIMIT_NPROC, u64::MAX),
                    (RLIMIT_CORE, 0),
                    (RLIMIT_NOFILE, OPEN_FILE_LIMIT),
                    (RLIMIT_AS, VIRTUAL_MEMORY_LIMIT),
                ]
            );
        }

        #[test]
        fn capability_last_parser_accepts_only_the_supported_kernel_range() {
            assert_eq!(parse_capability_last("0\n"), Some(0));
            assert_eq!(parse_capability_last("40\n"), Some(40));
            assert_eq!(parse_capability_last("63\n"), Some(63));
            for rejected in ["", "40", "64\n", "-1\n", "40\n\n", "4294967296\n"] {
                assert_eq!(parse_capability_last(rejected), None, "{rejected:?}");
            }
        }

        #[test]
        fn capability_status_requires_every_zero_set_and_no_new_privileges() {
            assert!(capability_status_is_locked(LOCKED_STATUS));
            assert!(capability_status_is_locked(&format!(
                "{LOCKED_STATUS}CapFuture:\t0000000000000000\n"
            )));

            for nonzero in ["CapInh", "CapPrm", "CapEff", "CapBnd", "CapAmb"] {
                let status = LOCKED_STATUS.replacen(
                    &format!("{nonzero}:\t0000000000000000"),
                    &format!("{nonzero}:\t0000000000000001"),
                    1,
                );
                assert!(!capability_status_is_locked(&status), "{nonzero}");
            }
            assert!(!capability_status_is_locked(
                &LOCKED_STATUS.replace("NoNewPrivs:\t1", "NoNewPrivs:\t0")
            ));
            assert!(!capability_status_is_locked(
                &LOCKED_STATUS.replace("CapAmb:\t0000000000000000\n", "")
            ));
            assert!(!capability_status_is_locked(&format!(
                "{LOCKED_STATUS}CapEff:\t0000000000000000\n"
            )));
            assert!(!capability_status_is_locked(&format!(
                "{LOCKED_STATUS}CapFuture:\t0000000000000001\n"
            )));
        }
    }
}

#[derive(Debug)]
struct InvocationWorkspace {
    invocation_id: u64,
    root: PathBuf,
    rootfs: PathBuf,
    rootfs_handle: File,
    writable: BTreeMap<&'static str, PathBuf>,
    work: PathBuf,
    work_handle: File,
    writable_handles: BTreeMap<&'static str, File>,
    driver_request: PathBuf,
    driver_request_handle: File,
    driver_request_bytes: Vec<u8>,
}

impl InvocationWorkspace {
    fn create(
        parent: &Path,
        snapshot: &Path,
        frontend: &Path,
        toolchain: &Path,
        driver_request_bytes: &[u8],
    ) -> Result<Self, SandboxError> {
        let invocation_id = NEXT_INVOCATION.fetch_add(1, Ordering::Relaxed);
        let root = parent.join(format!(
            "rust2vir-sandbox-{}-{invocation_id}",
            std::process::id()
        ));
        fs::create_dir(&root).map_err(|_| SandboxError::SandboxUnavailable)?;
        set_mode(&root, 0o700)?;
        let result = (|| {
            let rootfs = root.join("rootfs");
            let work = root.join("work");
            fs::create_dir(&rootfs).map_err(|_| SandboxError::SandboxUnavailable)?;
            fs::create_dir(&work).map_err(|_| SandboxError::SandboxUnavailable)?;
            set_mode(&rootfs, 0o700)?;
            set_mode(&work, 0o500)?;
            let mut writable = BTreeMap::new();
            for (virtual_path, name) in [
                (HOME_ROOT, "home"),
                (crate::environment::CARGO_HOME_ROOT, "cargo-home"),
                (TEMP_ROOT, "tmp"),
                (TARGET_ROOT, "target"),
                (DRIVER_OUTPUT_ROOT, "driver-output"),
            ] {
                let path = root.join(name);
                fs::create_dir(&path).map_err(|_| SandboxError::SandboxUnavailable)?;
                set_mode(&path, 0o700)?;
                writable.insert(virtual_path, path);
            }
            let (driver_request, driver_request_handle) =
                create_driver_request(&root, driver_request_bytes)?;
            create_rootfs_mountpoints(&rootfs)?;
            let rootfs_handle = open_workspace_directory(&rootfs)?;
            let work_handle = open_workspace_directory(&work)?;
            let writable_handles = writable
                .iter()
                .map(|(sandbox_path, host_path)| {
                    Ok((*sandbox_path, open_workspace_directory(host_path)?))
                })
                .collect::<Result<BTreeMap<_, _>, SandboxError>>()?;
            let workspace = Self {
                invocation_id,
                root: root.clone(),
                rootfs,
                rootfs_handle,
                writable,
                work,
                work_handle,
                writable_handles,
                driver_request,
                driver_request_handle,
                driver_request_bytes: driver_request_bytes.to_vec(),
            };
            workspace.validate(snapshot, frontend, toolchain)?;
            Ok(workspace)
        })();
        if result.is_err() {
            let _ = make_tree_private(&root);
            let _ = fs::remove_dir_all(&root);
        }
        result
    }

    fn writable_host_path(&self, sandbox_path: &str) -> Option<&Path> {
        self.writable.get(sandbox_path).map(PathBuf::as_path)
    }

    fn driver_request_host_path(&self) -> &Path {
        &self.driver_request
    }

    fn driver_output_handle(&self) -> &File {
        &self.writable_handles[DRIVER_OUTPUT_ROOT]
    }

    #[cfg(target_os = "linux")]
    fn retained_descriptors(&self) -> [i32; 7] {
        [
            self.work_handle.as_raw_fd(),
            self.writable_handles[HOME_ROOT].as_raw_fd(),
            self.writable_handles[crate::environment::CARGO_HOME_ROOT].as_raw_fd(),
            self.writable_handles[TEMP_ROOT].as_raw_fd(),
            self.writable_handles[TARGET_ROOT].as_raw_fd(),
            self.writable_handles[DRIVER_OUTPUT_ROOT].as_raw_fd(),
            self.driver_request_handle.as_raw_fd(),
        ]
    }

    fn validate(
        &self,
        snapshot: &Path,
        frontend: &Path,
        toolchain: &Path,
    ) -> Result<(), SandboxError> {
        let roots = [
            snapshot,
            frontend,
            toolchain,
            self.rootfs.as_path(),
            self.work.as_path(),
            self.writable[HOME_ROOT].as_path(),
            self.writable[crate::environment::CARGO_HOME_ROOT].as_path(),
            self.writable[TEMP_ROOT].as_path(),
            self.writable[TARGET_ROOT].as_path(),
            self.writable[DRIVER_OUTPUT_ROOT].as_path(),
        ];
        let mut identities = BTreeSet::new();
        for path in roots {
            let metadata =
                fs::symlink_metadata(path).map_err(|_| SandboxError::SandboxUnavailable)?;
            if !metadata.is_dir() || metadata.file_type().is_symlink() {
                return Err(SandboxError::SandboxUnavailable);
            }
            let identity = directory_identity(&metadata)?;
            if !identities.insert(identity) {
                return Err(SandboxError::SandboxUnavailable);
            }
        }
        let mut retained = vec![
            (self.rootfs.as_path(), &self.rootfs_handle),
            (self.work.as_path(), &self.work_handle),
        ];
        retained.extend(self.writable.iter().map(|(sandbox_path, host_path)| {
            (host_path.as_path(), &self.writable_handles[sandbox_path])
        }));
        for (path, handle) in retained {
            let named = fs::symlink_metadata(path).map_err(|_| SandboxError::SandboxUnavailable)?;
            let opened = handle
                .metadata()
                .map_err(|_| SandboxError::SandboxUnavailable)?;
            if directory_identity(&named)? != directory_identity(&opened)? {
                return Err(SandboxError::SandboxUnavailable);
            }
        }
        if fs::read_dir(&self.work)
            .map_err(|_| SandboxError::SandboxUnavailable)?
            .next()
            .is_some()
        {
            return Err(SandboxError::SandboxUnavailable);
        }
        for path in self.writable.values() {
            let metadata =
                fs::symlink_metadata(path).map_err(|_| SandboxError::SandboxUnavailable)?;
            if metadata_mode(&metadata)? & 0o7777 != 0o700 {
                return Err(SandboxError::SandboxUnavailable);
            }
        }
        if metadata_mode(
            &self
                .work_handle
                .metadata()
                .map_err(|_| SandboxError::SandboxUnavailable)?,
        )? & 0o7777
            != 0o500
        {
            return Err(SandboxError::SandboxUnavailable);
        }
        let rootfs_metadata = self
            .rootfs_handle
            .metadata()
            .map_err(|_| SandboxError::SandboxUnavailable)?;
        if metadata_mode(&rootfs_metadata)? & 0o7777 != 0o700 {
            return Err(SandboxError::SandboxUnavailable);
        }
        validate_rootfs_scaffold(&self.rootfs)?;
        validate_driver_request(
            &self.driver_request,
            &self.driver_request_handle,
            &self.driver_request_bytes,
        )?;
        Ok(())
    }

    #[cfg(target_os = "linux")]
    fn validate_resource_filesystem(&self, limits: SandboxLimits) -> Result<(), SandboxError> {
        let writable = [
            self.writable[HOME_ROOT].as_path(),
            self.writable[crate::environment::CARGO_HOME_ROOT].as_path(),
            self.writable[TEMP_ROOT].as_path(),
            self.writable[TARGET_ROOT].as_path(),
            self.writable[DRIVER_OUTPUT_ROOT].as_path(),
        ];
        linux::validate_resource_filesystem(&self.root, &writable, limits)
            .map_err(|_| SandboxError::SandboxUnavailable)
    }

    fn validate_before(&self, _kind: CargoInvocationKind) -> Result<(), SandboxError> {
        if tree_usage(&self.writable[TARGET_ROOT])? != (0, 0)
            || tree_usage(&self.writable[DRIVER_OUTPUT_ROOT])? != (0, 0)
        {
            return Err(SandboxError::SandboxUnavailable);
        }
        Ok(())
    }

    fn validate_after(&self, kind: CargoInvocationKind) -> Result<(), SandboxError> {
        if kind == CargoInvocationKind::Metadata
            && (tree_usage(&self.writable[TARGET_ROOT])? != (0, 0)
                || tree_usage(&self.writable[DRIVER_OUTPUT_ROOT])? != (0, 0))
        {
            return Err(SandboxError::SandboxUnavailable);
        }
        Ok(())
    }
}

impl Drop for InvocationWorkspace {
    fn drop(&mut self) {
        let _ = make_tree_private(&self.root);
        let _ = fs::remove_dir_all(&self.root);
    }
}

fn create_rootfs_mountpoints(root: &Path) -> Result<(), SandboxError> {
    for path in ROOTFS_DIRECTORIES {
        fs::create_dir_all(root.join(path)).map_err(|_| SandboxError::SandboxUnavailable)?;
    }
    let interpreter = root.join(ROOTFS_INTERPRETER);
    File::create(&interpreter).map_err(|_| SandboxError::SandboxUnavailable)?;
    set_mode(&interpreter, 0o444)?;
    let request = root.join(ROOTFS_DRIVER_REQUEST);
    File::create(&request).map_err(|_| SandboxError::SandboxUnavailable)?;
    set_mode(&request, 0o444)?;
    let null = root.join(ROOTFS_NULL);
    File::create(&null).map_err(|_| SandboxError::SandboxUnavailable)?;
    set_mode(&null, 0o444)?;
    for path in ROOTFS_DIRECTORIES {
        set_mode(&root.join(path), 0o555)?;
    }
    validate_rootfs_scaffold(root)
}

const ROOTFS_DIRECTORIES: [&str; 16] = [
    "dev",
    "lib",
    "lib/x86_64-linux-gnu",
    "lib64",
    "mpk",
    "mpk/cargo-home",
    "mpk/driver-output",
    "mpk/frontend",
    "mpk/home",
    "mpk/input",
    "mpk/native-runtime",
    "mpk/target",
    "mpk/tmp",
    "mpk/toolchain",
    "mpk/work",
    "proc",
];
const ROOTFS_INTERPRETER: &str = "lib64/ld-linux-x86-64.so.2";
const ROOTFS_DRIVER_REQUEST: &str = "mpk/driver-request.json";
const ROOTFS_NULL: &str = "dev/null";

fn validate_rootfs_scaffold(root: &Path) -> Result<(), SandboxError> {
    let mut directories = BTreeSet::new();
    let mut files = BTreeSet::new();
    let mut pending = vec![root.to_path_buf()];
    while let Some(directory) = pending.pop() {
        for entry in fs::read_dir(&directory).map_err(|_| SandboxError::SandboxUnavailable)? {
            let entry = entry.map_err(|_| SandboxError::SandboxUnavailable)?;
            let path = entry.path();
            let metadata =
                fs::symlink_metadata(&path).map_err(|_| SandboxError::SandboxUnavailable)?;
            if metadata.file_type().is_symlink() {
                return Err(SandboxError::SandboxUnavailable);
            }
            let relative = path
                .strip_prefix(root)
                .map_err(|_| SandboxError::SandboxUnavailable)?
                .to_str()
                .ok_or(SandboxError::SandboxUnavailable)?
                .to_owned();
            if metadata.is_dir() {
                if metadata_mode(&metadata)? & 0o7777 != 0o555 || !directories.insert(relative) {
                    return Err(SandboxError::SandboxUnavailable);
                }
                pending.push(path);
            } else if metadata.is_file() {
                if metadata_mode(&metadata)? & 0o7777 != 0o444
                    || metadata.len() != 0
                    || metadata_link_count(&metadata)? != 1
                    || !files.insert(relative)
                {
                    return Err(SandboxError::SandboxUnavailable);
                }
            } else {
                return Err(SandboxError::SandboxUnavailable);
            }
        }
    }
    let expected_directories = ROOTFS_DIRECTORIES.into_iter().map(str::to_owned).collect();
    let expected_files = [
        ROOTFS_NULL.to_owned(),
        ROOTFS_INTERPRETER.to_owned(),
        ROOTFS_DRIVER_REQUEST.to_owned(),
    ]
    .into_iter()
    .collect();
    if directories != expected_directories || files != expected_files {
        return Err(SandboxError::SandboxUnavailable);
    }
    Ok(())
}

fn create_driver_request(root: &Path, bytes: &[u8]) -> Result<(PathBuf, File), SandboxError> {
    if bytes.len() > driver_protocol::REQUEST_TRANSPORT_MAX {
        return Err(SandboxError::SandboxUnavailable);
    }
    let path = root.join("driver-request.json");
    let mut options = OpenOptions::new();
    options.read(true).write(true).create_new(true);
    #[cfg(target_os = "linux")]
    options.mode(0o600).custom_flags(0o400_000 | 0o2_000_000);
    let mut writer = options
        .open(&path)
        .map_err(|_| SandboxError::SandboxUnavailable)?;
    writer
        .write_all(bytes)
        .map_err(|_| SandboxError::SandboxUnavailable)?;
    writer
        .flush()
        .map_err(|_| SandboxError::SandboxUnavailable)?;
    writer
        .sync_all()
        .map_err(|_| SandboxError::SandboxUnavailable)?;
    set_mode(&path, 0o400)?;
    writer
        .sync_all()
        .map_err(|_| SandboxError::SandboxUnavailable)?;
    drop(writer);
    File::open(root)
        .and_then(|directory| directory.sync_all())
        .map_err(|_| SandboxError::SandboxUnavailable)?;
    let handle = open_workspace_regular(&path)?;
    validate_driver_request(&path, &handle, bytes)?;
    Ok((path, handle))
}

fn validate_driver_request(
    path: &Path,
    handle: &File,
    expected: &[u8],
) -> Result<(), SandboxError> {
    let named = fs::symlink_metadata(path).map_err(|_| SandboxError::SandboxUnavailable)?;
    let opened = handle
        .metadata()
        .map_err(|_| SandboxError::SandboxUnavailable)?;
    if !named.is_file()
        || named.file_type().is_symlink()
        || metadata_mode(&named)? & 0o7777 != 0o400
        || metadata_link_count(&named)? != 1
        || regular_file_identity(&named)? != regular_file_identity(&opened)?
        || named.len() != expected.len() as u64
    {
        return Err(SandboxError::SandboxUnavailable);
    }
    let mut reader = handle
        .try_clone()
        .map_err(|_| SandboxError::SandboxUnavailable)?;
    reader
        .seek(SeekFrom::Start(0))
        .map_err(|_| SandboxError::SandboxUnavailable)?;
    let mut bytes = Vec::with_capacity(expected.len());
    let read_limit = expected
        .len()
        .checked_add(1)
        .and_then(|limit| u64::try_from(limit).ok())
        .ok_or(SandboxError::SandboxUnavailable)?;
    reader
        .take(read_limit)
        .read_to_end(&mut bytes)
        .map_err(|_| SandboxError::SandboxUnavailable)?;
    if bytes != expected
        || regular_file_identity(
            &fs::symlink_metadata(path).map_err(|_| SandboxError::SandboxUnavailable)?,
        )? != regular_file_identity(
            &handle
                .metadata()
                .map_err(|_| SandboxError::SandboxUnavailable)?,
        )?
    {
        return Err(SandboxError::SandboxUnavailable);
    }
    Ok(())
}

fn required_file<'a>(
    inventory: &'a [InventoryFile],
    path: &str,
    executable: bool,
) -> Result<&'a InventoryFile, SandboxError> {
    let file = inventory
        .binary_search_by_key(&path, |file| file.path.as_str())
        .ok()
        .map(|index| &inventory[index])
        .ok_or(SandboxError::ToolchainComponent)?;
    if file.executable != executable {
        return Err(SandboxError::ToolchainComponent);
    }
    Ok(file)
}

fn validate_inventory_shape(inventory: &[InventoryFile]) -> Result<(), SandboxError> {
    if inventory.is_empty() || inventory.len() > CANDIDATE_FILE_COUNT_LIMIT {
        return Err(SandboxError::ToolchainComponent);
    }
    let mut previous: Option<&str> = None;
    let mut casefolded = BTreeSet::new();
    let mut aggregate = 0_u64;
    for file in inventory {
        file.validate_shape()?;
        aggregate = aggregate
            .checked_add(file.size_bytes)
            .ok_or(SandboxError::ToolchainComponent)?;
        if file.size_bytes > CANDIDATE_FILE_SIZE_LIMIT
            || aggregate > CANDIDATE_AGGREGATE_LIMIT
            || previous.is_some_and(|path| path >= file.path.as_str())
            || !casefolded.insert(file.path.to_ascii_lowercase())
        {
            return Err(SandboxError::ToolchainComponent);
        }
        previous = Some(&file.path);
    }
    Ok(())
}

fn inventory_from_root(root: &Path) -> Result<Vec<InventoryFile>, SandboxError> {
    let metadata = fs::symlink_metadata(root).map_err(|_| SandboxError::ToolchainComponent)?;
    if !metadata.is_dir()
        || metadata.file_type().is_symlink()
        || metadata_mode(&metadata)? & 0o7777 != 0o555
    {
        return Err(SandboxError::ToolchainComponent);
    }
    let handle = open_directory_nofollow(root)?;
    let retained_metadata = handle
        .metadata()
        .map_err(|_| SandboxError::ToolchainComponent)?;
    if directory_identity(&metadata)? != directory_identity(&retained_metadata)? {
        return Err(SandboxError::ToolchainComponent);
    }
    #[cfg(target_os = "linux")]
    let retained_root = PathBuf::from(format!("/proc/self/fd/{}", handle.as_raw_fd()));
    #[cfg(not(target_os = "linux"))]
    let retained_root = root.to_path_buf();

    let mut paths = Vec::new();
    collect_regular_files(
        &retained_root,
        &retained_root,
        metadata_device(&retained_metadata)?,
        &mut paths,
    )?;
    paths.sort_by(|left, right| left.as_bytes().cmp(right.as_bytes()));
    if paths.len() > CANDIDATE_FILE_COUNT_LIMIT {
        return Err(SandboxError::ToolchainComponent);
    }
    let mut aggregate = 0_u64;
    let mut inventory = Vec::with_capacity(paths.len());
    for path in paths {
        let absolute = retained_root.join(&path);
        let metadata =
            fs::symlink_metadata(&absolute).map_err(|_| SandboxError::ToolchainComponent)?;
        let mode = metadata_mode(&metadata)? & 0o7777;
        if !metadata.is_file()
            || metadata.file_type().is_symlink()
            || metadata_link_count(&metadata)? != 1
            || !matches!(mode, 0o444 | 0o555)
            || metadata.len() > CANDIDATE_FILE_SIZE_LIMIT
        {
            return Err(SandboxError::ToolchainComponent);
        }
        aggregate = aggregate
            .checked_add(metadata.len())
            .filter(|size| *size <= CANDIDATE_AGGREGATE_LIMIT)
            .ok_or(SandboxError::ToolchainComponent)?;
        let identity = regular_file_identity(&metadata)?;
        let file = open_regular_nofollow(&absolute)?;
        if regular_file_identity(
            &file
                .metadata()
                .map_err(|_| SandboxError::ToolchainComponent)?,
        )? != identity
        {
            return Err(SandboxError::ToolchainComponent);
        }
        let mut bytes = Vec::with_capacity(
            usize::try_from(metadata.len()).map_err(|_| SandboxError::ToolchainComponent)?,
        );
        file.take(
            metadata
                .len()
                .checked_add(1)
                .ok_or(SandboxError::ToolchainComponent)?,
        )
        .read_to_end(&mut bytes)
        .map_err(|_| SandboxError::ToolchainComponent)?;
        if bytes.len() as u64 != metadata.len()
            || regular_file_identity(
                &fs::symlink_metadata(&absolute).map_err(|_| SandboxError::ToolchainComponent)?,
            )? != identity
        {
            return Err(SandboxError::ToolchainComponent);
        }
        inventory.push(InventoryFile::new(
            path,
            mode == 0o555,
            metadata.len(),
            hex(&digest(&bytes)),
        )?);
    }
    validate_inventory_shape(&inventory)?;
    Ok(inventory)
}

fn validate_inventory_root(root: &Path, inventory: &[InventoryFile]) -> Result<File, SandboxError> {
    let root_metadata = fs::symlink_metadata(root).map_err(|_| SandboxError::ToolchainComponent)?;
    if !root_metadata.is_dir()
        || root_metadata.file_type().is_symlink()
        || metadata_mode(&root_metadata)? & 0o7777 != 0o555
    {
        return Err(SandboxError::ToolchainComponent);
    }
    let handle = open_directory_nofollow(root)?;
    let retained_metadata = handle
        .metadata()
        .map_err(|_| SandboxError::ToolchainComponent)?;
    if directory_identity(&root_metadata)? != directory_identity(&retained_metadata)? {
        return Err(SandboxError::ToolchainComponent);
    }

    #[cfg(target_os = "linux")]
    let retained_root = PathBuf::from(format!("/proc/self/fd/{}", handle.as_raw_fd()));
    #[cfg(not(target_os = "linux"))]
    let retained_root = root.to_path_buf();

    let mut observed = Vec::new();
    collect_regular_files(
        &retained_root,
        &retained_root,
        metadata_device(&retained_metadata)?,
        &mut observed,
    )?;
    observed.sort_by(|left, right| left.as_bytes().cmp(right.as_bytes()));
    if observed.len() != inventory.len()
        || observed
            .iter()
            .map(String::as_str)
            .ne(inventory.iter().map(|file| file.path.as_str()))
    {
        return Err(SandboxError::ToolchainComponent);
    }
    for expected in inventory {
        let path = retained_root.join(&expected.path);
        let metadata = fs::symlink_metadata(&path).map_err(|_| SandboxError::ToolchainComponent)?;
        if !metadata.is_file()
            || metadata.file_type().is_symlink()
            || metadata.len() != expected.size_bytes
            || metadata_link_count(&metadata)? != 1
            || metadata_mode(&metadata)? & 0o7777 != if expected.executable { 0o555 } else { 0o444 }
        {
            return Err(SandboxError::ToolchainComponent);
        }
        let identity = regular_file_identity(&metadata)?;
        let file = open_regular_nofollow(&path)?;
        if regular_file_identity(
            &file
                .metadata()
                .map_err(|_| SandboxError::ToolchainComponent)?,
        )? != identity
            || regular_file_identity(
                &fs::symlink_metadata(&path).map_err(|_| SandboxError::ToolchainComponent)?,
            )? != identity
        {
            return Err(SandboxError::ToolchainComponent);
        }
        let mut bytes = Vec::with_capacity(
            usize::try_from(expected.size_bytes).map_err(|_| SandboxError::ToolchainComponent)?,
        );
        file.take(
            expected
                .size_bytes
                .checked_add(1)
                .ok_or(SandboxError::ToolchainComponent)?,
        )
        .read_to_end(&mut bytes)
        .map_err(|_| SandboxError::ToolchainComponent)?;
        if bytes.len() as u64 != expected.size_bytes || hex(&digest(&bytes)) != expected.sha256 {
            return Err(SandboxError::ToolchainComponent);
        }
    }
    Ok(handle)
}

fn collect_regular_files(
    root: &Path,
    directory: &Path,
    root_device: u64,
    output: &mut Vec<String>,
) -> Result<(), SandboxError> {
    let mut entries = fs::read_dir(directory)
        .map_err(|_| SandboxError::ToolchainComponent)?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|_| SandboxError::ToolchainComponent)?;
    entries.sort_by_key(fs::DirEntry::file_name);
    for entry in entries {
        let path = entry.path();
        let metadata = fs::symlink_metadata(&path).map_err(|_| SandboxError::ToolchainComponent)?;
        if metadata.file_type().is_symlink() || metadata_device(&metadata)? != root_device {
            return Err(SandboxError::ToolchainComponent);
        }
        if metadata.is_dir() {
            if metadata_mode(&metadata)? & 0o7777 != 0o555 {
                return Err(SandboxError::ToolchainComponent);
            }
            let file_count = output.len();
            collect_regular_files(root, &path, root_device, output)?;
            if output.len() == file_count {
                return Err(SandboxError::ToolchainComponent);
            }
        } else if metadata.is_file() {
            let relative = path
                .strip_prefix(root)
                .map_err(|_| SandboxError::ToolchainComponent)?
                .to_str()
                .ok_or(SandboxError::ToolchainComponent)?
                .to_owned();
            validate_relative_path(&relative)?;
            output.push(relative);
        } else {
            return Err(SandboxError::ToolchainComponent);
        }
    }
    Ok(())
}

#[cfg(target_os = "linux")]
fn open_regular_nofollow(path: &Path) -> Result<File, SandboxError> {
    const O_NOFOLLOW: i32 = 0o400_000;
    const O_CLOEXEC: i32 = 0o2_000_000;
    OpenOptions::new()
        .read(true)
        .custom_flags(O_NOFOLLOW | O_CLOEXEC)
        .open(path)
        .map_err(|_| SandboxError::ToolchainComponent)
}

#[cfg(not(target_os = "linux"))]
fn open_regular_nofollow(path: &Path) -> Result<File, SandboxError> {
    let metadata = fs::symlink_metadata(path).map_err(|_| SandboxError::ToolchainComponent)?;
    if !metadata.is_file() || metadata.file_type().is_symlink() {
        return Err(SandboxError::ToolchainComponent);
    }
    File::open(path).map_err(|_| SandboxError::ToolchainComponent)
}

fn validate_distinct_roots(left: &File, right: &File) -> Result<(), SandboxError> {
    let left = left
        .metadata()
        .map_err(|_| SandboxError::ToolchainComponent)?;
    let right = right
        .metadata()
        .map_err(|_| SandboxError::ToolchainComponent)?;
    if directory_identity(&left)? == directory_identity(&right)? {
        return Err(SandboxError::ToolchainComponent);
    }
    Ok(())
}

fn open_workspace_directory(path: &Path) -> Result<File, SandboxError> {
    open_directory_nofollow(path).map_err(|_| SandboxError::SandboxUnavailable)
}

fn open_workspace_regular(path: &Path) -> Result<File, SandboxError> {
    open_regular_nofollow(path).map_err(|_| SandboxError::SandboxUnavailable)
}

#[cfg(target_os = "linux")]
fn open_directory_nofollow(path: &Path) -> Result<File, SandboxError> {
    const O_DIRECTORY: i32 = 0o200_000;
    const O_NOFOLLOW: i32 = 0o400_000;
    const O_CLOEXEC: i32 = 0o2_000_000;
    OpenOptions::new()
        .read(true)
        .custom_flags(O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC)
        .open(path)
        .map_err(|_| SandboxError::ToolchainComponent)
}

#[cfg(not(target_os = "linux"))]
fn open_directory_nofollow(path: &Path) -> Result<File, SandboxError> {
    let metadata = fs::symlink_metadata(path).map_err(|_| SandboxError::ToolchainComponent)?;
    if !metadata.is_dir() || metadata.file_type().is_symlink() {
        return Err(SandboxError::ToolchainComponent);
    }
    OpenOptions::new()
        .read(true)
        .open(path)
        .map_err(|_| SandboxError::ToolchainComponent)
}

fn validate_relative_path(path: &str) -> Result<(), SandboxError> {
    let candidate = Path::new(path);
    if path.is_empty()
        || path.len() > CANDIDATE_PATH_LIMIT
        || path.contains(['\\', '\0'])
        || !path.is_ascii()
        || !candidate
            .components()
            .all(|component| matches!(component, Component::Normal(value) if !value.is_empty()))
    {
        return Err(SandboxError::ToolchainComponent);
    }
    Ok(())
}

fn validate_sha256(value: &str) -> Result<(), SandboxError> {
    if value.len() != 64
        || !value
            .bytes()
            .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
    {
        return Err(SandboxError::ToolchainComponent);
    }
    Ok(())
}

pub fn toolchain_distribution_sha256(bundle_id: &str, inventory: &[InventoryFile]) -> String {
    inventory_content_sha256(bundle_id, "toolchain_bundle", None, inventory)
}

pub fn frontend_bundle_sha256(bundle_id: &str, inventory: &[InventoryFile]) -> String {
    inventory_content_sha256(bundle_id, "frontend_bundle", None, inventory)
}

pub fn component_content_sha256(
    bundle_id: &str,
    component_name: &str,
    inventory: &[InventoryFile],
    path_prefix: &str,
) -> String {
    let files = inventory
        .iter()
        .filter(|file| file.path.starts_with(path_prefix))
        .cloned()
        .collect::<Vec<_>>();
    inventory_content_sha256(bundle_id, "component", Some(component_name), &files)
}

fn inventory_content_sha256(
    bundle_id: &str,
    scope_kind: &str,
    component_name: Option<&str>,
    inventory: &[InventoryFile],
) -> String {
    let mut payload = String::from("{\"files\":[");
    for (index, file) in inventory.iter().enumerate() {
        if index != 0 {
            payload.push(',');
        }
        payload.push_str("{\"executable\":");
        payload.push_str(if file.executable { "true" } else { "false" });
        payload.push_str(",\"path\":");
        push_json_string(&mut payload, &file.path);
        payload.push_str(",\"sha256\":");
        push_json_string(&mut payload, &file.sha256);
        payload.push_str(",\"size_bytes\":");
        payload.push_str(&file.size_bytes.to_string());
        payload.push('}');
    }
    payload.push_str("],\"schema\":\"mpk.release.bundle_inventory.v0\",\"scope\":{");
    payload.push_str("\"bundle_id\":");
    push_json_string(&mut payload, bundle_id);
    if let Some(component_name) = component_name {
        payload.push_str(",\"component_name\":");
        push_json_string(&mut payload, component_name);
    }
    payload.push_str(",\"kind\":");
    push_json_string(&mut payload, scope_kind);
    payload.push('}');
    payload.push('}');
    let mut preimage = b"MPK-BUNDLE-CONTENT-0.1\0".to_vec();
    preimage.extend_from_slice(payload.as_bytes());
    hex(&digest(&preimage))
}

fn push_json_string(output: &mut String, value: &str) {
    output.push('"');
    for character in value.chars() {
        match character {
            '"' => output.push_str("\\\""),
            '\\' => output.push_str("\\\\"),
            '\u{8}' => output.push_str("\\b"),
            '\u{c}' => output.push_str("\\f"),
            '\n' => output.push_str("\\n"),
            '\r' => output.push_str("\\r"),
            '\t' => output.push_str("\\t"),
            '\u{0}'..='\u{1f}' => {
                use std::fmt::Write as _;
                let _ = write!(output, "\\u{:04x}", u32::from(character));
            }
            character => output.push(character),
        }
    }
    output.push('"');
}

fn tree_usage(root: &Path) -> Result<(u64, u64), SandboxError> {
    let mut files = 0_u64;
    let mut bytes = 0_u64;
    let mut pending = vec![root.to_path_buf()];
    while let Some(directory) = pending.pop() {
        for entry in fs::read_dir(directory).map_err(|_| SandboxError::FilesystemLimit)? {
            let entry = entry.map_err(|_| SandboxError::FilesystemLimit)?;
            let metadata =
                fs::symlink_metadata(entry.path()).map_err(|_| SandboxError::FilesystemLimit)?;
            if metadata.file_type().is_symlink() {
                return Err(SandboxError::FilesystemLimit);
            }
            if metadata.is_dir() {
                pending.push(entry.path());
            } else if metadata.is_file() {
                files = files.checked_add(1).ok_or(SandboxError::FilesystemLimit)?;
                bytes = bytes
                    .checked_add(metadata.len())
                    .ok_or(SandboxError::FilesystemLimit)?;
            } else {
                return Err(SandboxError::FilesystemLimit);
            }
        }
    }
    Ok((files, bytes))
}

#[cfg(all(test, target_os = "linux"))]
mod usage_tests {
    use super::*;

    #[test]
    fn second_process_reader_enforces_aggregate_remaining_allowance() {
        let aggregate_maximum = 7_usize;
        let first_process_observed = 5_usize;
        let second_process_allowance = aggregate_maximum
            .checked_sub(first_process_observed)
            .unwrap();
        let overflow = Arc::new(AtomicBool::new(false));
        let read_failed = Arc::new(AtomicBool::new(false));
        let reader = bounded_reader(
            std::io::Cursor::new(vec![0_u8; second_process_allowance + 1]),
            second_process_allowance,
            true,
            Arc::clone(&overflow),
            Arc::clone(&read_failed),
        );
        let (retained, observed) = reader.join().unwrap();

        assert_eq!(observed, second_process_allowance + 1);
        assert_eq!(retained.len(), second_process_allowance + 1);
        assert!(overflow.load(Ordering::Acquire));
        assert!(!read_failed.load(Ordering::Acquire));
    }
}

fn make_tree_private(root: &Path) -> io::Result<()> {
    let metadata = fs::symlink_metadata(root)?;
    if metadata.file_type().is_symlink() {
        return Err(io::Error::from(io::ErrorKind::InvalidInput));
    }
    if metadata.is_dir() {
        fs::set_permissions(root, fs::Permissions::from_mode(0o700))?;
        for entry in fs::read_dir(root)? {
            make_tree_private(&entry?.path())?;
        }
    } else if metadata.is_file() {
        fs::set_permissions(root, fs::Permissions::from_mode(0o600))?;
    } else {
        return Err(io::Error::from(io::ErrorKind::InvalidInput));
    }
    Ok(())
}

#[cfg(unix)]
fn set_mode(path: &Path, mode: u32) -> Result<(), SandboxError> {
    fs::set_permissions(path, fs::Permissions::from_mode(mode))
        .map_err(|_| SandboxError::SandboxUnavailable)
}

#[cfg(not(unix))]
fn set_mode(_path: &Path, _mode: u32) -> Result<(), SandboxError> {
    Err(SandboxError::SandboxUnavailable)
}

#[cfg(unix)]
fn directory_identity(metadata: &Metadata) -> Result<(u64, u64), SandboxError> {
    Ok((metadata.dev(), metadata.ino()))
}

#[cfg(not(unix))]
fn directory_identity(_metadata: &Metadata) -> Result<(u64, u64), SandboxError> {
    Err(SandboxError::SandboxUnavailable)
}

#[cfg(unix)]
fn metadata_device(metadata: &Metadata) -> Result<u64, SandboxError> {
    Ok(metadata.dev())
}

#[cfg(not(unix))]
fn metadata_device(_metadata: &Metadata) -> Result<u64, SandboxError> {
    Err(SandboxError::SandboxUnavailable)
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct RegularFileIdentity {
    device: u64,
    inode: u64,
    mode: u32,
    links: u64,
    length: u64,
    modified_seconds: i64,
    modified_nanoseconds: i64,
    changed_seconds: i64,
    changed_nanoseconds: i64,
}

#[cfg(unix)]
fn regular_file_identity(metadata: &Metadata) -> Result<RegularFileIdentity, SandboxError> {
    Ok(RegularFileIdentity {
        device: metadata.dev(),
        inode: metadata.ino(),
        mode: metadata.mode(),
        links: metadata.nlink(),
        length: metadata.len(),
        modified_seconds: metadata.mtime(),
        modified_nanoseconds: metadata.mtime_nsec(),
        changed_seconds: metadata.ctime(),
        changed_nanoseconds: metadata.ctime_nsec(),
    })
}

#[cfg(not(unix))]
fn regular_file_identity(_metadata: &Metadata) -> Result<RegularFileIdentity, SandboxError> {
    Err(SandboxError::SandboxUnavailable)
}

#[cfg(unix)]
fn metadata_mode(metadata: &Metadata) -> Result<u32, SandboxError> {
    Ok(metadata.mode())
}

#[cfg(not(unix))]
fn metadata_mode(_metadata: &Metadata) -> Result<u32, SandboxError> {
    Err(SandboxError::SandboxUnavailable)
}

#[cfg(unix)]
fn metadata_link_count(metadata: &Metadata) -> Result<u64, SandboxError> {
    Ok(metadata.nlink())
}

#[cfg(not(unix))]
fn metadata_link_count(_metadata: &Metadata) -> Result<u64, SandboxError> {
    Err(SandboxError::SandboxUnavailable)
}

pub fn fixed_read_only_views() -> [&'static str; 6] {
    [
        INPUT_ROOT,
        TOOLCHAIN_ROOT,
        FRONTEND_ROOT,
        WORK_ROOT,
        NATIVE_RUNTIME_ROOT,
        driver_protocol::REQUEST_PATH,
    ]
}

pub fn fixed_writable_views() -> [&'static str; 5] {
    fixed_writable_mount_views().map(|(path, _)| path)
}

pub fn fixed_writable_mount_views() -> [(&'static str, bool); 5] {
    [
        (HOME_ROOT, false),
        (crate::environment::CARGO_HOME_ROOT, false),
        (TEMP_ROOT, false),
        (TARGET_ROOT, true),
        (DRIVER_OUTPUT_ROOT, false),
    ]
}
