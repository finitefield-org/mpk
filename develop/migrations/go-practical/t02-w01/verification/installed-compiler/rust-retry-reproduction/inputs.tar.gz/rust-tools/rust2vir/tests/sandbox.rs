mod common;

use common::{frozen_environment, metadata_json, Fixture};
use rust2vir_internal::cargo_metadata::{MetadataCode, MetadataPhase};
use rust2vir_internal::driver_process::read_request;
use rust2vir_internal::driver_protocol::DriverProtocolCode;
use rust2vir_internal::environment::{EvidenceEnvironment, ENCODED_RUSTFLAGS_ELEMENTS};
use rust2vir_internal::sandbox::{
    fixed_read_only_views, fixed_writable_mount_views, fixed_writable_views, CargoInvocation,
    ProcessOutput, SandboxContext, SandboxError, SandboxExecutor, CGROUP_MEMORY_LIMIT,
    CGROUP_SWAP_LIMIT, CGROUP_TASK_LIMIT, OPEN_FILE_LIMIT, RESOURCE_PROFILE_ID, STDERR_BYTES_LIMIT,
    STDOUT_BYTES_LIMIT, VIRTUAL_MEMORY_LIMIT, WRITABLE_ALLOCATED_BYTES_LIMIT, WRITABLE_INODE_LIMIT,
};
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::process::Command;
use std::sync::{Arc, Mutex};

#[derive(Clone)]
struct SharedExecutor {
    calls: Arc<Mutex<usize>>,
    responses: Arc<Mutex<Vec<Result<ProcessOutput, SandboxError>>>>,
}

#[derive(Default)]
struct RequestMountExecutor;

impl SandboxExecutor for RequestMountExecutor {
    fn execute(
        &mut self,
        context: &SandboxContext<'_>,
        invocation: &CargoInvocation,
    ) -> Result<ProcessOutput, SandboxError> {
        assert_eq!(
            invocation.kind(),
            rust2vir_internal::sandbox::CargoInvocationKind::Metadata
        );
        let path = context.driver_request_host_path();
        assert_eq!(
            fs::symlink_metadata(path).unwrap().permissions().mode() & 0o7777,
            0o400
        );
        let bytes = read_request(path).unwrap();
        assert_eq!(bytes, context.driver_request().transport());
        assert!(context
            .environment()
            .entries()
            .keys()
            .all(|name| !name.starts_with("MPK_")));
        let placeholder = context.rootfs().join("mpk/driver-request.json");
        let placeholder = fs::symlink_metadata(placeholder).unwrap();
        assert!(placeholder.is_file());
        assert_eq!(placeholder.len(), 0);
        assert_eq!(placeholder.permissions().mode() & 0o7777, 0o444);
        Ok(ProcessOutput::success(metadata_json()))
    }
}

impl SandboxExecutor for SharedExecutor {
    fn execute(
        &mut self,
        context: &SandboxContext<'_>,
        _invocation: &CargoInvocation,
    ) -> Result<ProcessOutput, SandboxError> {
        assert_eq!(context.environment().entries(), &frozen_environment());
        *self.calls.lock().unwrap() += 1;
        self.responses.lock().unwrap().remove(0)
    }
}

#[test]
fn environment_views_and_limits_are_the_exact_closed_profiles() {
    let environment = EvidenceEnvironment::frozen();
    environment.validate().unwrap();
    assert_eq!(environment.entries(), &frozen_environment());
    assert_eq!(
        environment
            .encoded_rustflags()
            .split('\u{1f}')
            .collect::<Vec<_>>(),
        ENCODED_RUSTFLAGS_ELEMENTS
    );
    assert_eq!(
        fixed_read_only_views(),
        [
            "/mpk/input",
            "/mpk/toolchain",
            "/mpk/frontend",
            "/mpk/work",
            "/mpk/native-runtime",
            "/mpk/driver-request.json",
        ]
    );
    assert_eq!(
        fixed_writable_views(),
        [
            "/mpk/home",
            "/mpk/cargo-home",
            "/mpk/tmp",
            "/mpk/target",
            "/mpk/driver-output",
        ]
    );
    assert_eq!(
        fixed_writable_mount_views(),
        [
            ("/mpk/home", false),
            ("/mpk/cargo-home", false),
            ("/mpk/tmp", false),
            ("/mpk/target", true),
            ("/mpk/driver-output", false),
        ]
    );
    assert_eq!(
        RESOURCE_PROFILE_ID,
        "mpk.rust.build_resources.cgroup2_tmpfs.v0"
    );
    assert_eq!(CGROUP_TASK_LIMIT, 256);
    assert_eq!(OPEN_FILE_LIMIT, 1_024);
    assert_eq!(VIRTUAL_MEMORY_LIMIT, 17_179_869_184);
    assert_eq!(CGROUP_MEMORY_LIMIT, 34_359_738_368);
    assert_eq!(CGROUP_SWAP_LIMIT, 0);
    assert_eq!(WRITABLE_ALLOCATED_BYTES_LIMIT, 21_474_836_480);
    assert_eq!(WRITABLE_INODE_LIMIT, 262_144);
    assert_eq!(STDOUT_BYTES_LIMIT, 67_108_864);
    assert_eq!(STDERR_BYTES_LIMIT, 2_097_152);
}

#[test]
fn operational_filesystem_and_private_request_failures_keep_exact_ownership() {
    assert_eq!(
        SandboxError::FilesystemLimit.code(),
        "RUST_FRONTEND_COMPILER_CRASH"
    );
    let request_limit =
        MetadataCode::Sandbox(SandboxError::DriverProtocol(DriverProtocolCode::Transport));
    assert_eq!(
        request_limit.as_str(),
        "RUST_FRONTEND_DRIVER_PROTOCOL_TRANSPORT"
    );
    assert_eq!(request_limit.phase(), "typecheck");
}

#[test]
fn private_request_is_sealed_before_any_cargo_process_and_uses_no_mpk_environment() {
    let mut fixture = Fixture::new();
    let metadata_request = fixture.metadata_request();
    let (_, _) = MetadataPhase::prepare(
        fixture.request(),
        fixture.snapshot(),
        metadata_request,
        fixture.candidate(),
        fixture.private_parent(),
        RequestMountExecutor,
    )
    .unwrap()
    .run()
    .unwrap();
}

#[test]
fn sandbox_unavailable_is_not_retried_with_a_second_response() {
    let calls = Arc::new(Mutex::new(0));
    let executor = SharedExecutor {
        calls: Arc::clone(&calls),
        responses: Arc::new(Mutex::new(vec![
            Err(SandboxError::SandboxUnavailable),
            Ok(ProcessOutput::success(metadata_json())),
        ])),
    };
    let mut fixture = Fixture::new();
    let metadata_request = fixture.metadata_request();
    let error = MetadataPhase::prepare(
        fixture.request(),
        fixture.snapshot(),
        metadata_request,
        fixture.candidate(),
        fixture.private_parent(),
        executor,
    )
    .unwrap()
    .run()
    .err()
    .expect("sandbox failure must be terminal");
    assert_eq!(
        error.code,
        MetadataCode::Sandbox(SandboxError::SandboxUnavailable)
    );
    assert_eq!(error.code.as_str(), "FRONTEND_SANDBOX_UNAVAILABLE");
    assert_eq!(*calls.lock().unwrap(), 1);
}

#[test]
fn every_process_rehashes_candidate_files_before_executor_entry() {
    let calls = Arc::new(Mutex::new(0));
    let executor = SharedExecutor {
        calls: Arc::clone(&calls),
        responses: Arc::new(Mutex::new(vec![Ok(
            ProcessOutput::success(metadata_json()),
        )])),
    };
    let mut fixture = Fixture::new();
    let rustc = fixture.toolchain_root().join("bin/rustc");
    let metadata_request = fixture.metadata_request();
    let phase = MetadataPhase::prepare(
        fixture.request(),
        fixture.snapshot(),
        metadata_request,
        fixture.candidate(),
        fixture.private_parent(),
        executor,
    )
    .unwrap();

    fs::set_permissions(&rustc, fs::Permissions::from_mode(0o700)).unwrap();
    fs::write(&rustc, b"replaced compiler").unwrap();
    fs::set_permissions(&rustc, fs::Permissions::from_mode(0o555)).unwrap();
    let error = phase
        .run()
        .err()
        .expect("candidate replacement must reject");
    assert_eq!(
        error.code,
        MetadataCode::Sandbox(SandboxError::ToolchainComponent)
    );
    assert_eq!(*calls.lock().unwrap(), 0);
}

#[test]
fn every_process_rejects_noncanonical_candidate_modes() {
    let calls = Arc::new(Mutex::new(0));
    let executor = SharedExecutor {
        calls: Arc::clone(&calls),
        responses: Arc::new(Mutex::new(vec![Ok(
            ProcessOutput::success(metadata_json()),
        )])),
    };
    let mut fixture = Fixture::new();
    let rustc = fixture.toolchain_root().join("bin/rustc");
    let metadata_request = fixture.metadata_request();
    let phase = MetadataPhase::prepare(
        fixture.request(),
        fixture.snapshot(),
        metadata_request,
        fixture.candidate(),
        fixture.private_parent(),
        executor,
    )
    .unwrap();

    fs::set_permissions(&rustc, fs::Permissions::from_mode(0o500)).unwrap();
    let error = phase
        .run()
        .err()
        .expect("noncanonical installed mode must reject");
    assert_eq!(
        error.code,
        MetadataCode::Sandbox(SandboxError::ToolchainComponent)
    );
    assert_eq!(*calls.lock().unwrap(), 0);
}

#[test]
fn launcher_assertion_mismatch_rejects_before_sandbox_or_process_creation() {
    let calls = Arc::new(Mutex::new(0));
    let executor = SharedExecutor {
        calls: Arc::clone(&calls),
        responses: Arc::new(Mutex::new(vec![Ok(
            ProcessOutput::success(metadata_json()),
        )])),
    };
    let mut fixture = Fixture::new();
    let metadata_request = fixture.metadata_request();
    let mut request = fixture.request().clone();
    request.release.driver_sha256 =
        "0000000000000000000000000000000000000000000000000000000000000000".to_owned();
    let error = MetadataPhase::prepare(
        &request,
        fixture.snapshot(),
        metadata_request,
        fixture.candidate(),
        fixture.private_parent(),
        executor,
    )
    .err()
    .expect("launcher assertion mismatch must reject");
    assert_eq!(
        error.code,
        MetadataCode::Sandbox(SandboxError::ToolchainComponent)
    );
    assert_eq!(*calls.lock().unwrap(), 0);
}

#[test]
fn private_bootstrap_rejects_incomplete_state_without_running_a_child() {
    for bootstrap in [
        "__rust2vir_cargo_sandbox_v0",
        "__rust2vir_cargo_outer_sandbox_v0",
    ] {
        let output = Command::new(env!("CARGO_BIN_EXE_rust2vir"))
            .arg(bootstrap)
            .arg("/untrusted")
            .output()
            .unwrap();
        assert_eq!(output.status.code(), Some(125));
        assert!(output.stdout.is_empty());
        assert!(output.stderr.is_empty());
    }
}
