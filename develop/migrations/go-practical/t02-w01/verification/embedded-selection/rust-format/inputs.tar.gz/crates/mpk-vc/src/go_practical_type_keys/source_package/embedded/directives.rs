//! Native go/build's byte comment walk, independently applied to whole originals.
//! Malformed argument lines are ignored as in go/build; compiler enforcement
//! of pragma placement/variables remains part of original compilation authority.
use super::super::super::source_scopes;
use super::decode;

fn space(r: u32) -> bool {
    matches!(r, 0x09..=0x0d | 0x20 | 0x85 | 0xa0 | 0x1680 | 0x2000..=0x200a | 0x2028 | 0x2029 | 0x202f | 0x205f | 0x3000)
}
fn args(raw: &[u8]) -> Option<Vec<Vec<u8>>> {
    let mut at = 0;
    let mut result = vec![];
    loop {
        while at < raw.len() {
            let (r, n) = decode(&raw[at..]);
            if !space(r) {
                break;
            }
            at += n;
        }
        if at == raw.len() {
            return Some(result);
        }
        let start = at;
        let value = match raw[at] {
            b'`' => {
                at += 1;
                let end = at + raw[at..].iter().position(|b| *b == b'`')?;
                let value = raw[at..end].to_vec();
                at = end + 1;
                value
            }
            b'"' => {
                at += 1;
                loop {
                    match raw.get(at)? {
                        b'"' => { at += 1; break; }
                        b'\\' => at += 2,
                        _ => at += 1,
                    }
                }
                source_scopes::unquote(&raw[start..at]).ok()?
            }
            _ => {
                while at < raw.len() {
                    let (r, n) = decode(&raw[at..]);
                    if space(r) {
                        break;
                    }
                    at += n;
                }
                raw[start..at].to_vec()
            }
        };
        if at < raw.len() && !space(decode(&raw[at..]).0) {
            return None;
        }
        result.push(value);
    }
}
pub(super) fn read(raw: &[u8]) -> Vec<Vec<u8>> {
    let mut at = usize::from(raw.starts_with(&[0xef, 0xbb, 0xbf])) * 3;
    let mut line_start = false;
    let mut result = vec![];
    while at < raw.len() && raw[at] != 0 {
        let c = raw[at];
        at += 1;
        match c {
            b'\n' => line_start = true,
            b' ' | b'\t' => {}
            b'"' | b'\'' | b'`' => {
                line_start = false;
                loop {
                    let Some(&next) = raw.get(at) else { return result; };
                    if next == 0 { return result; }
                    at += 1;
                    if next == c { break; }
                    if next == b'\\' && c != b'`' {
                        if raw.get(at).is_none_or(|b| *b == 0) { return result; }
                        at += 1;
                    }
                }
            }
            b'/' if raw.get(at) == Some(&b'*') => {
                at += 1;
                loop {
                    if at == raw.len() || raw[at] == 0 { return result; }
                    if raw[at..].starts_with(b"*/") { at += 2; break; }
                    at += 1;
                }
                line_start = false;
            }
            b'/' if raw.get(at) == Some(&b'/') => {
                at += 1;
                let start = at;
                while at < raw.len() && !matches!(raw[at], b'\n' | 0) { at += 1; }
                if line_start && raw[start..at].starts_with(b"go:embed") && matches!(raw.get(start + 8), Some(b' ' | b'\t')) {
                    if let Some(patterns) = args(&raw[start + 9..at]) { result.extend(patterns); }
                }
                line_start = true;
            }
            _ => line_start = false,
        }
    }
    result
}
