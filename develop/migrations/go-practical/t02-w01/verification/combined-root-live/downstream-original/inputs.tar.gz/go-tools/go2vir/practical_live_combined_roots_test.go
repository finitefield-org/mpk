//go:build go1.25 && (linux || darwin)

package main

import (
	"os"
	"path/filepath"
	"testing"
)

// Coordinate the existing complete original owner with an independent test
// observer that has retained both root sets since their live comparisons.
// This hook is absent from normal capture and provides no launcher authority.
func practicalLiveCombinedOwnerFinish(t *testing.T, sources, exports, total int) {
	t.Helper()
	directory := os.Getenv("MPK_GO_LIVE_COMBINED_COORD")
	if directory == "" {
		return
	}
	evidence := os.Getenv("MPK_GO_PRACTICAL_SYNTAX_EVIDENCE")
	if !filepath.IsAbs(directory) || !filepath.IsAbs(evidence) || sources == 0 || exports == 0 || sources+exports != total {
		t.Fatal("combined root observer requires the complete original owner")
	}
	practicalLiveRootSignal(t, directory, "owner-ready.json", map[string]any{
		"owner_path":       filepath.Join(evidence, "complete-original-module-graph-inputs.json"),
		"source_directory": evidence,
		"source_objects":   sources, "export_objects": exports, "total_objects": total,
		"original_roots_retired": true, "export_cache_retired": true,
	})
	matched := practicalLiveRootWait(t, directory, "owner-matched.json")
	if matched["source_objects"] != float64(sources) || matched["export_objects"] != float64(exports) || matched["total_objects"] != float64(total) || matched["both_root_sets_retained"] != true {
		t.Fatal("combined observer did not bind every original source and export object")
	}
	t.Log("both independently held original root sets match the complete original export owner")
}
