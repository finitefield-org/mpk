struct Normalizer<'a> {
    b: &'a mut Builder,
    step_label: &'static str,
    heads: BTreeMap<u32, u32>,
    substitutions: BTreeMap<(u32, u32, u32), u32>,
    shifts: BTreeMap<(u32, u32, u32), u32>,
    proofs: BTreeMap<u32, (bool, u32, u32)>,
    context_facts: BTreeMap<u32, (bool, u32)>,
    inline_limit: u32,
    share_atoms: bool,
    share_word_transport: bool,
    atoms: BTreeMap<u32, u32>,
    word_values: BTreeMap<u32, u32>,
    word_muxes: BTreeMap<u32, Option<(u32, u32)>>,
}
impl Normalizer<'_> {
    fn word_transport(&mut self, function: u32) -> R<String> {
        let name = format!("{PREFIX}.OwnershipProof.WordTransport");
        if self.b.globals.contains_key(&name) {
            return Ok(name);
        }
        let cube = self.b.cube(5)?;
        let boolean = self.b.boolean;
        // a,b,c,d : C5; a=c; b=d; r : Bool; WordEqual(c,d)=r.
        let a = self.b.var(3)?;
        let c = self.b.var(1)?;
        let left_ty = call(self.b, EQ, vec![cube, a, c])?;
        let b = self.b.var(3)?;
        let d = self.b.var(1)?;
        let right_ty = call(self.b, EQ, vec![cube, b, d])?;
        let c = self.b.var(4)?;
        let d = self.b.var(3)?;
        let result = self.b.var(0)?;
        let comparison = self.b.app(function, vec![c, d])?;
        let comparison_ty = call(self.b, EQ, vec![boolean, comparison, result])?;
        let binders = [
            cube,
            cube,
            cube,
            cube,
            left_ty,
            right_ty,
            boolean,
            comparison_ty,
        ];
        let a = self.b.var(7)?;
        let b = self.b.var(6)?;
        let c = self.b.var(5)?;
        let d = self.b.var(4)?;
        let left_eq = self.b.var(3)?;
        let right_eq = self.b.var(2)?;
        let result = self.b.var(1)?;
        let comparison_eq = self.b.var(0)?;
        let variable = self.b.var(0)?;
        let inner_b = self.b.var(7)?;
        let body = self.b.app(function, vec![variable, inner_b])?;
        let left_fun = self.b.lam(cube, body)?;
        let left = call(
            self.b,
            "Std.Eq.congr",
            vec![cube, boolean, left_fun, a, c, left_eq],
        )?;
        let inner_c = self.b.var(6)?;
        let body = self.b.app(function, vec![inner_c, variable])?;
        let right_fun = self.b.lam(cube, body)?;
        let right = call(
            self.b,
            "Std.Eq.congr",
            vec![cube, boolean, right_fun, b, d, right_eq],
        )?;
        let original = self.b.app(function, vec![a, b])?;
        let middle = self.b.app(function, vec![c, b])?;
        let canonical = self.b.app(function, vec![c, d])?;
        let joined = call(
            self.b,
            "Std.Eq.trans",
            vec![boolean, original, middle, canonical, left, right],
        )?;
        let mut proof = call(
            self.b,
            "Std.Eq.trans",
            vec![boolean, original, canonical, result, joined, comparison_eq],
        )?;
        let mut ty = call(self.b, EQ, vec![boolean, original, result])?;
        for binder in binders.into_iter().rev() {
            proof = self.b.lam(binder, proof)?;
            ty = self.b.pi(binder, ty)?;
        }
        self.publish(&name, ty, proof)?;
        Ok(name)
    }
    fn bool_step(&mut self, selected: bool) -> R<String> {
        let name = format!("{PREFIX}.OwnershipProof.BoolStep.{selected}");
        if self.b.globals.contains_key(&name) {
            return Ok(name);
        }
        // For arbitrary branches n/y, condition c and result r:
        // c = selected -> branch = r -> rec n y c = r.
        // Sharing this ordinary theorem avoids re-inferring a fresh lambda
        // containing both complete concrete branches at every reduction step.
        let boolean = self.b.boolean;
        let chosen = bit(self.b, selected)?;
        let condition = self.b.var(1)?;
        let condition_ty = call(self.b, EQ, vec![boolean, condition, chosen])?;
        let branch = self.b.var(if selected { 3 } else { 4 })?;
        let result = self.b.var(1)?;
        let branch_ty = call(self.b, EQ, vec![boolean, branch, result])?;
        let binders = [boolean, boolean, boolean, boolean, condition_ty, branch_ty];
        let no = self.b.var(5)?;
        let yes = self.b.var(4)?;
        let condition = self.b.var(3)?;
        let result = self.b.var(2)?;
        let condition_proof = self.b.var(1)?;
        let branch_proof = self.b.var(0)?;
        let expression = call(self.b, "Std.Bool.rec", vec![no, yes, condition])?;
        let branch = if selected { yes } else { no };
        let inner_no = self.b.var(6)?;
        let inner_yes = self.b.var(5)?;
        let variable = self.b.var(0)?;
        let body = call(self.b, "Std.Bool.rec", vec![inner_no, inner_yes, variable])?;
        let fun = self.b.lam(boolean, body)?;
        let congr = call(
            self.b,
            "Std.Eq.congr",
            vec![boolean, boolean, fun, condition, chosen, condition_proof],
        )?;
        let mut proof = call(
            self.b,
            "Std.Eq.trans",
            vec![boolean, expression, branch, result, congr, branch_proof],
        )?;
        let mut ty = call(self.b, EQ, vec![boolean, expression, result])?;
        for binder in binders.into_iter().rev() {
            proof = self.b.lam(binder, proof)?;
            ty = self.b.pi(binder, ty)?;
        }
        self.publish(&name, ty, proof)?;
        Ok(name)
    }
    fn shift(&mut self, t: u32, amount: u32, cutoff: u32) -> R<u32> {
        if amount == 0 {
            return Ok(t);
        }
        if let Some(r) = self.shifts.get(&(t, amount, cutoff)) {
            return Ok(*r);
        }
        let node = match self.b.c.term_table[t as usize].clone() {
            TermNode::Var(i) if i >= cutoff => {
                TermNode::Var(i.checked_add(amount).ok_or(OrdinaryCarrierError::Limit)?)
            }
            TermNode::App {
                function,
                arguments,
            } => TermNode::App {
                function: self.shift(function, amount, cutoff)?,
                arguments: arguments
                    .into_iter()
                    .map(|a| self.shift(a, amount, cutoff))
                    .collect::<R<Vec<_>>>()?,
            },
            TermNode::Lam { ty, body } => TermNode::Lam {
                ty: self.shift(ty, amount, cutoff)?,
                body: self.shift(body, amount, cutoff + 1)?,
            },
            TermNode::Pi { ty, body } => TermNode::Pi {
                ty: self.shift(ty, amount, cutoff)?,
                body: self.shift(body, amount, cutoff + 1)?,
            },
            TermNode::Let { ty, value, body } => TermNode::Let {
                ty: self.shift(ty, amount, cutoff)?,
                value: self.shift(value, amount, cutoff)?,
                body: self.shift(body, amount, cutoff + 1)?,
            },
            node => node,
        };
        let result = self.b.term(node)?;
        self.shifts.insert((t, amount, cutoff), result);
        Ok(result)
    }
    fn substitute(&mut self, t: u32, depth: u32, value: u32) -> R<u32> {
        if let Some(r) = self.substitutions.get(&(t, depth, value)) {
            return Ok(*r);
        }
        let node = self.b.c.term_table[t as usize].clone();
        let node = match node {
            TermNode::Var(i) if i == depth => {
                // Word-wide congruence also opens applications under the five
                // selector binders. Preserve free selectors without capture.
                let shifted = self.shift(value, depth, 0)?;
                self.substitutions.insert((t, depth, value), shifted);
                return Ok(shifted);
            }
            TermNode::Var(i) if i > depth => TermNode::Var(i - 1),
            TermNode::App {
                function,
                arguments,
            } => TermNode::App {
                function: self.substitute(function, depth, value)?,
                arguments: arguments
                    .into_iter()
                    .map(|a| self.substitute(a, depth, value))
                    .collect::<R<Vec<_>>>()?,
            },
            TermNode::Lam { ty, body } => TermNode::Lam {
                ty: self.substitute(ty, depth, value)?,
                body: self.substitute(body, depth + 1, value)?,
            },
            TermNode::Pi { ty, body } => TermNode::Pi {
                ty: self.substitute(ty, depth, value)?,
                body: self.substitute(body, depth + 1, value)?,
            },
            TermNode::Let { ty, value: v, body } => TermNode::Let {
                ty: self.substitute(ty, depth, value)?,
                value: self.substitute(v, depth, value)?,
                body: self.substitute(body, depth + 1, value)?,
            },
            node => node,
        };
        let result = self.b.term(node)?;
        self.substitutions.insert((t, depth, value), result);
        Ok(result)
    }
    fn head(&mut self, t: u32) -> R<u32> {
        if self.word_call(t).is_some() {
            return Ok(t);
        }
        if let Some(r) = self.heads.get(&t) {
            return Ok(*r);
        }
        let node = self.b.c.term_table[t as usize].clone();
        let result = match node {
            TermNode::Const { global, .. } => match self.b.c.declarations[global as usize].kind {
                DeclarationKind::Def {
                    value,
                    reducibility: DefinitionReducibility::Reducible,
                    ..
                } => self.head(value)?,
                _ => t,
            },
            TermNode::Let { value, body, .. } => {
                let reduced = self.substitute(body, 0, value)?;
                self.head(reduced)?
            }
            TermNode::App {
                function,
                arguments,
            } => {
                let mut function = self.head(function)?;
                let mut arguments = arguments;
                if self.inline_limit == u32::MAX {
                    // Captured source predicates apply curried functions one
                    // argument at a time. Preserve Builder's original syntax,
                    // but expose the complete spine before recognizing a
                    // Boolean recursor or substituting its lambda binders.
                    while let TermNode::App {
                        function: inner,
                        arguments: prefix,
                    } = self.b.c.term_table[function as usize].clone()
                    {
                        let mut all = prefix;
                        all.append(&mut arguments);
                        arguments = all;
                        function = self.head(inner)?;
                    }
                }
                if let TermNode::Lam { body, .. } = self.b.c.term_table[function as usize] {
                    let reduced = self.substitute(body, 0, arguments[0])?;
                    let reduced = self.b.app(reduced, arguments[1..].to_vec())?;
                    self.head(reduced)?
                } else if matches!(self.b.c.term_table[function as usize], TermNode::Const {global,..} if self.b.c.name_table[self.b.c.declarations[global as usize].name as usize] == "Std.Bool.rec")
                    && arguments.len() == 3
                {
                    // Only a literal constructor major is an ordinary iota
                    // conversion. Computed conditions still need explicit proof.
                    let branch = match self.b.c.term_table[arguments[2] as usize] {
                        TermNode::Const { global, .. } => match self.b.c.name_table
                            [self.b.c.declarations[global as usize].name as usize]
                            .as_str()
                        {
                            "Std.Bool.false" => Some(arguments[0]),
                            "Std.Bool.true" => Some(arguments[1]),
                            _ => None,
                        },
                        _ => None,
                    };
                    if let Some(branch) = branch {
                        self.head(branch)?
                    } else {
                        self.b.app(function, arguments)?
                    }
                } else {
                    self.b.app(function, arguments)?
                }
            }
            _ => t,
        };
        self.heads.insert(t, result);
        Ok(result)
    }
    fn word_call(&self, t: u32) -> Option<(u32, Vec<u32>)> {
        let TermNode::App {
            function,
            arguments,
        } = &self.b.c.term_table[t as usize]
        else {
            return None;
        };
        let TermNode::Const { global, .. } = self.b.c.term_table[*function as usize] else {
            return None;
        };
        (arguments.len() == 2
            && self.b.c.name_table[self.b.c.declarations[global as usize].name as usize]
                == format!("{PREFIX}.OwnershipFlow.WordEqual"))
        .then(|| (*function, arguments.clone()))
    }
    fn literal_tree(&mut self, t: u32) -> R<Option<u32>> {
        match self.b.c.term_table[t as usize].clone() {
            TermNode::Var(i) if i < 5 => Ok(Some(t)),
            TermNode::Const { global, .. } => {
                let name =
                    &self.b.c.name_table[self.b.c.declarations[global as usize].name as usize];
                Ok(matches!(name.as_str(), "Std.Bool.false" | "Std.Bool.true").then_some(t))
            }
            TermNode::App {
                function,
                arguments,
            } if arguments.len() == 3 => {
                let TermNode::Const { global, .. } = self.b.c.term_table[function as usize] else {
                    return Ok(None);
                };
                if self.b.c.name_table[self.b.c.declarations[global as usize].name as usize]
                    != "Std.Bool.rec"
                {
                    return Ok(None);
                }
                match self.b.c.term_table[arguments[2] as usize] {
                    TermNode::Const { global, .. } => {
                        let selected = match self.b.c.name_table
                            [self.b.c.declarations[global as usize].name as usize]
                            .as_str()
                        {
                            "Std.Bool.false" => 0,
                            "Std.Bool.true" => 1,
                            _ => return Ok(None),
                        };
                        self.literal_tree(arguments[selected])
                    }
                    TermNode::Var(i) if i < 5 => {
                        let Some(no) = self.literal_tree(arguments[0])? else {
                            return Ok(None);
                        };
                        let Some(yes) = self.literal_tree(arguments[1])? else {
                            return Ok(None);
                        };
                        Ok(Some(self.b.app(function, vec![no, yes, arguments[2]])?))
                    }
                    _ => Ok(None),
                }
            }
            _ => Ok(None),
        }
    }
    fn literal_word(&mut self, t: u32) -> R<Option<u32>> {
        let mut body = self.head(t)?;
        for _ in 0..5 {
            let TermNode::Lam { ty, body: inner } = self.b.c.term_table[body as usize] else {
                return Ok(None);
            };
            if ty != self.b.boolean {
                return Ok(None);
            }
            body = inner;
        }
        let Some(body) = self.literal_tree(body)? else {
            return Ok(None);
        };
        let word = self.b.wrap_selectors(5, body)?;
        if !self.share_atoms {
            return Ok(Some(word));
        }
        if let Some(value) = self.word_values.get(&word) {
            return Ok(Some(*value));
        }
        // Inference of a constant uses its already checked C5 type. Reusing
        // literal carriers avoids rechecking the same lambda tree in every
        // equality/prefix proof; their complete selector bodies remain checked.
        let name = format!(
            "{PREFIX}.OwnershipProof.WordValue.N{}",
            self.b.c.declarations.len()
        );
        let ty = self.b.cube(5)?;
        self.b.define(&name, ty, word)?;
        let value = self.b.constant(&name)?;
        self.word_values.insert(word, value);
        Ok(Some(value))
    }
    // A closed word-wide condition has one equality proof, rather than one
    // copy per output bit. Congruence transports the complete C5 function;
    // this is not an unproved eager reduction of a computed recursor major.
    fn mux_word(&mut self, term: u32) -> R<Option<(u32, u32)>> {
        if let Some(result) = self.word_muxes.get(&term) {
            return Ok(*result);
        }
        let result = self.mux_word_inner(term)?;
        self.word_muxes.insert(term, result);
        Ok(result)
    }
    fn mux_word_inner(&mut self, term: u32) -> R<Option<(u32, u32)>> {
        let mut body = self.head(term)?;
        for _ in 0..5 {
            let TermNode::Lam { ty, body: next } = self.b.c.term_table[body as usize] else {
                return Ok(None);
            };
            if ty != self.b.boolean {
                return Ok(None);
            }
            body = next;
        }
        body = self.head(body)?;
        let TermNode::App {
            function,
            arguments,
        } = self.b.c.term_table[body as usize].clone()
        else {
            return Ok(None);
        };
        let TermNode::Const { global, .. } = self.b.c.term_table[function as usize] else {
            return Ok(None);
        };
        if arguments.len() != 3
            || self.b.c.name_table[self.b.c.declarations[global as usize].name as usize]
                != "Std.Bool.rec"
        {
            return Ok(None);
        }
        fn closed(b: &Builder, term: u32, depth: u32, seen: &mut BTreeSet<(u32, u32)>) -> bool {
            if !seen.insert((term, depth)) {
                return true;
            }
            match &b.c.term_table[term as usize] {
                TermNode::Var(index) => *index < depth,
                TermNode::Sort(_) | TermNode::Const { .. } => true,
                TermNode::App {
                    function,
                    arguments,
                } => {
                    closed(b, *function, depth, seen)
                        && arguments.iter().all(|a| closed(b, *a, depth, seen))
                }
                TermNode::Lam { ty, body } | TermNode::Pi { ty, body } => {
                    closed(b, *ty, depth, seen) && closed(b, *body, depth + 1, seen)
                }
                TermNode::Let { ty, value, body } => {
                    closed(b, *ty, depth, seen)
                        && closed(b, *value, depth, seen)
                        && closed(b, *body, depth + 1, seen)
                }
            }
        }
        let condition = arguments[2];
        // A condition depending on selector variables needs a different proof.
        if !closed(self.b, condition, 0, &mut BTreeSet::new()) {
            return Ok(None);
        }
        let (selected, condition_proof, _) = self.normalize(condition)?;
        let branch = self.head(arguments[usize::from(selected)])?;
        let selected_word = self.b.wrap_selectors(5, branch)?;
        let cube = self.b.cube(5)?;
        let (canonical, selected_proof) = if let Some(word) = self.literal_word(selected_word)? {
            (word, call(self.b, REFL, vec![cube, word])?)
        } else if let Some(result) = self.mux_word(selected_word)? {
            result
        } else {
            return Ok(None);
        };
        let parameter = self.b.var(5)?;
        let body = self
            .b
            .app(function, vec![arguments[0], arguments[1], parameter])?;
        let body = self.b.wrap_selectors(5, body)?;
        let fun = self.b.lam(self.b.boolean, body)?;
        let selected = bit(self.b, selected)?;
        let congr = call(
            self.b,
            "Std.Eq.congr",
            vec![
                self.b.boolean,
                cube,
                fun,
                condition,
                selected,
                condition_proof,
            ],
        )?;
        let proof = call(
            self.b,
            "Std.Eq.trans",
            vec![cube, term, selected_word, canonical, congr, selected_proof],
        )?;
        let ty = call(self.b, EQ, vec![cube, term, canonical])?;
        let name = format!(
            "{PREFIX}.OwnershipProof.WordMux.N{}",
            self.b.c.declarations.len()
        );
        self.publish(&name, ty, proof)?;
        Ok(Some((canonical, self.b.constant(&name)?)))
    }
    // Sharing only constructor-valued selector computations keeps each
    // conversion local. A computed recursor major stays neutral: replacing it
    // by a literal would add an iota reduction absent from the original term.
    fn atom(&mut self, t: u32) -> R<u32> {
        if let Some(r) = self.atoms.get(&t) {
            return Ok(*r);
        }
        let h = self.head(t)?;
        let mut result = h;
        if let TermNode::App {
            function,
            arguments,
        } = self.b.c.term_table[h as usize].clone()
        {
            if let TermNode::Const { global, .. } = self.b.c.term_table[function as usize] {
                if self.b.c.name_table[self.b.c.declarations[global as usize].name as usize]
                    == "Std.Bool.rec"
                    && arguments.len() == 3
                {
                    let condition = self.head(arguments[2])?;
                    let literal = matches!(self.b.c.term_table[condition as usize], TermNode::Const { global, .. } if matches!(self.b.c.name_table[self.b.c.declarations[global as usize].name as usize].as_str(), "Std.Bool.true" | "Std.Bool.false"));
                    if literal {
                        let no = self.atom(arguments[0])?;
                        let yes = self.atom(arguments[1])?;
                        let variable = self.b.var(0)?;
                        let identity = self.b.lam(self.b.boolean, variable)?;
                        let neutral = self.b.app(identity, vec![condition])?;
                        result = self.b.app(function, vec![no, yes, neutral])?;
                    }
                }
            }
        }
        self.atoms.insert(t, result);
        Ok(result)
    }
    fn normalize(&mut self, t: u32) -> R<(bool, u32, u32)> {
        let h = if self.share_atoms {
            self.atom(t)?
        } else {
            self.head(t)?
        };
        if let Some(&(value, proof)) = self.context_facts.get(&h) {
            return Ok((value, proof, 1));
        }
        if let Some(r) = self.proofs.get(&h) {
            return Ok(*r);
        }
        if let Some((function, arguments)) = self.word_call(h) {
            let mut canonical = arguments.clone();
            let mut word_proofs = [None, None];
            for (i, arg) in canonical.iter_mut().enumerate() {
                if let Some(word) = self.literal_word(*arg)? {
                    *arg = word;
                } else if self.share_word_transport {
                    if let Some((word, proof)) = self.mux_word(*arg)? {
                        *arg = word;
                        word_proofs[i] = Some(proof);
                    }
                }
            }
            let result = if canonical != arguments {
                let shared = self.b.app(function, canonical.clone())?;
                let (value, reduced, _) = self.normalize(shared)?;
                let cube = self.b.cube(5)?;
                let expected = bit(self.b, value)?;
                let proof = if self.share_word_transport {
                    let transport = self.word_transport(function)?;
                    let left = match word_proofs[0] {
                        Some(proof) => proof,
                        None => call(self.b, REFL, vec![cube, canonical[0]])?,
                    };
                    let right = match word_proofs[1] {
                        Some(proof) => proof,
                        None => call(self.b, REFL, vec![cube, canonical[1]])?,
                    };
                    call(
                        self.b,
                        &transport,
                        vec![
                            arguments[0],
                            arguments[1],
                            canonical[0],
                            canonical[1],
                            left,
                            right,
                            expected,
                            reduced,
                        ],
                    )?
                } else {
                    let variable = self.b.var(0)?;
                    let right_argument = self.shift(arguments[1], 1, 0)?;
                    let left_body = self.b.app(function, vec![variable, right_argument])?;
                    let left_fun = self.b.lam(cube, left_body)?;
                    let left_refl = call(self.b, REFL, vec![cube, canonical[0]])?;
                    let left = call(
                        self.b,
                        "Std.Eq.congr",
                        vec![
                            cube,
                            self.b.boolean,
                            left_fun,
                            arguments[0],
                            canonical[0],
                            left_refl,
                        ],
                    )?;
                    let left_argument = self.shift(canonical[0], 1, 0)?;
                    let right_body = self.b.app(function, vec![left_argument, variable])?;
                    let right_fun = self.b.lam(cube, right_body)?;
                    let right_refl = call(self.b, REFL, vec![cube, canonical[1]])?;
                    let right = call(
                        self.b,
                        "Std.Eq.congr",
                        vec![
                            cube,
                            self.b.boolean,
                            right_fun,
                            arguments[1],
                            canonical[1],
                            right_refl,
                        ],
                    )?;
                    let middle = self.b.app(function, vec![canonical[0], arguments[1]])?;
                    let joined = call(
                        self.b,
                        "Std.Eq.trans",
                        vec![self.b.boolean, h, middle, shared, left, right],
                    )?;
                    call(
                        self.b,
                        "Std.Eq.trans",
                        vec![self.b.boolean, h, shared, expected, joined, reduced],
                    )?
                };
                if self.inline_limit == u32::MAX {
                    // Context proofs may contain free variables. Keep them in
                    // their enclosing theorem, rather than publishing an open lemma.
                    (value, proof, 1)
                } else {
                    let ty = call(self.b, EQ, vec![self.b.boolean, h, expected])?;
                    let name = format!(
                        "{PREFIX}.OwnershipProof.Word.N{}",
                        self.b.c.declarations.len()
                    );
                    self.publish(&name, ty, proof)?;
                    (value, self.b.constant(&name)?, 1)
                }
            } else {
                let TermNode::Const { global, .. } = self.b.c.term_table[function as usize] else {
                    eprintln!("Unknown application {h}: {function} -> {:?}, args {arguments:?}; facts {:?}",self.b.c.term_table[function as usize], self.context_facts);
                    return Err(OrdinaryCarrierError::Linkage);
                };
                let DeclarationKind::Def { value, .. } =
                    self.b.c.declarations[global as usize].kind
                else {
                    return Err(OrdinaryCarrierError::Linkage);
                };
                let expanded = self.b.app(value, arguments)?;
                self.normalize(expanded)?
            };
            self.proofs.insert(h, result);
            return Ok(result);
        }
        let node = self.b.c.term_table[h as usize].clone();
        let result = match node {
            TermNode::Const { global, .. } => {
                let name =
                    &self.b.c.name_table[self.b.c.declarations[global as usize].name as usize];
                let value = match name.as_str() {
                    "Std.Bool.true" => true,
                    "Std.Bool.false" => false,
                    _ => return Err(OrdinaryCarrierError::Linkage),
                };
                let proof = call(self.b, REFL, vec![self.b.boolean, h])?;
                (value, proof, 1)
            }
            TermNode::App {
                function,
                arguments,
            } => {
                let TermNode::Const { global, .. } = self.b.c.term_table[function as usize] else {
                    eprintln!("Unknown application {h}: {function} -> {:?}, args {arguments:?}; facts {:?}",self.b.c.term_table[function as usize], self.context_facts);
                    return Err(OrdinaryCarrierError::Linkage);
                };
                if self.b.c.name_table[self.b.c.declarations[global as usize].name as usize]
                    != "Std.Bool.rec"
                    || arguments.len() != 3
                {
                    return Err(OrdinaryCarrierError::Linkage);
                }
                let (selected, condition_proof, condition_cost) = self.normalize(arguments[2])?;
                let branch = arguments[usize::from(selected)];
                let (value, branch_proof, branch_cost) = self.normalize(branch)?;
                let no = arguments[0];
                let yes = arguments[1];
                let condition_reference = arguments[2];
                let reference = h;
                let branch = if selected { yes } else { no };
                let result = bit(self.b, value)?;
                let proof = if self.share_atoms {
                    let step = self.bool_step(selected)?;
                    call(
                        self.b,
                        &step,
                        vec![
                            no,
                            yes,
                            condition_reference,
                            result,
                            condition_proof,
                            branch_proof,
                        ],
                    )?
                } else {
                    let variable = self.b.var(0)?;
                    let inner_no = self.shift(no, 1, 0)?;
                    let inner_yes = self.shift(yes, 1, 0)?;
                    let body = self.b.app(function, vec![inner_no, inner_yes, variable])?;
                    // Context facts can leave free values in either branch.
                    let fun = self.b.lam(self.b.boolean, body)?;
                    let condition = bit(self.b, selected)?;
                    let congr = call(
                        self.b,
                        "Std.Eq.congr",
                        vec![
                            self.b.boolean,
                            self.b.boolean,
                            fun,
                            condition_reference,
                            condition,
                            condition_proof,
                        ],
                    )?;
                    call(
                        self.b,
                        "Std.Eq.trans",
                        vec![
                            self.b.boolean,
                            reference,
                            branch,
                            result,
                            congr,
                            branch_proof,
                        ],
                    )?
                };
                (
                    value,
                    proof,
                    condition_cost.saturating_add(branch_cost).saturating_add(1),
                )
            }
            _ => return Err(OrdinaryCarrierError::Linkage),
        };
        let (value, proof, cost) = result;
        let result = if self.inline_limit != u32::MAX && cost >= self.inline_limit {
            let reference = h;
            let expected = bit(self.b, value)?;
            let ty = call(self.b, EQ, vec![self.b.boolean, reference, expected])?;
            let name = format!(
                "{PREFIX}.{}.Step.N{}",
                self.step_label,
                self.b.c.declarations.len()
            );
            self.publish(&name, ty, proof)?;
            (value, self.b.constant(&name)?, 1)
        } else {
            result
        };
        self.proofs.insert(h, result);
        Ok(result)
    }
    fn theorem(&mut self, definition: &str, expected: bool) -> R<String> {
        let value = self.b.constant(definition)?;
        let (actual, proof, _) = self.normalize(value)?;
        if actual != expected {
            return Err(OrdinaryCarrierError::Linkage);
        }
        let expected = bit(self.b, expected)?;
        let ty = call(self.b, EQ, vec![self.b.boolean, value, expected])?;
        let name = format!("{definition}.Proof");
        self.publish(&name, ty, proof)?;
        Ok(name)
    }
    fn publish(&mut self, name: &str, ty: u32, proof: u32) -> R<()> {
        publish_theorem(self.b, name, ty, proof)
    }
}
fn publish_theorem(b: &mut Builder, name: &str, ty: u32, proof: u32) -> R<()> {
    if b.globals.contains_key(name) {
        return Err(OrdinaryCarrierError::Linkage);
    }
    if b.c.declarations.len() >= 8192 {
        return Err(OrdinaryCarrierError::Limit);
    }
    let id = b.c.name_table.len() as u32;
    b.c.name_table.push(name.to_owned());
    b.globals
        .insert(name.to_owned(), b.c.declarations.len() as u32);
    b.c.declarations.push(Declaration {
        name: id,
        kind: DeclarationKind::Theorem { ty, proof },
    });
    Ok(())
}

fn prove_boolean_in_context(
    b: &mut Builder,
    expression: u32,
    expected: bool,
    facts: &[(u32, bool, u32)],
) -> R<u32> {
    let mut n = Normalizer {
        b,
        step_label: "ContextBooleanProof",
        heads: BTreeMap::new(),
        substitutions: BTreeMap::new(),
        shifts: BTreeMap::new(),
        proofs: BTreeMap::new(),
        context_facts: BTreeMap::new(),
        inline_limit: u32::MAX,
        share_atoms: false,
        share_word_transport: false,
        atoms: BTreeMap::new(),
        word_values: BTreeMap::new(),
        word_muxes: BTreeMap::new(),
    };
    for &(expression, value, proof) in facts {
        let head = n.head(expression)?;
        if let Some(&(prior, _)) = n.context_facts.get(&head) {
            if prior != value {
                return Err(OrdinaryCarrierError::Linkage);
            }
        } else {
            n.context_facts.insert(head, (value, proof));
        }
    }
    let (actual, proof, _) = n.normalize(expression)?;
    if actual != expected {
        return Err(OrdinaryCarrierError::Linkage);
    }
    Ok(proof)
}

