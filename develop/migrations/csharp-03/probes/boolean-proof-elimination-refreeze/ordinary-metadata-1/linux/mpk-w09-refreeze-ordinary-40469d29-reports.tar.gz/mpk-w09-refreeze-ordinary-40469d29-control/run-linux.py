import hashlib,json,os,pathlib,re,subprocess,time
control=pathlib.Path(__file__).parent;repo=pathlib.Path('/root/mpk-w09-refreeze-40469d29');out=pathlib.Path('/root/mpk-w09-refreeze-ordinary-40469d29-reports');target=pathlib.Path('/root/mpk-w09-refreeze-40469d29-target')
out.mkdir(exist_ok=False);manifest=json.loads((control/'manifest.json').read_bytes());state={'status':'preparing_public_source','supervisor_pid':os.getpid(),'source_commit':manifest['source_commit'],'source_files':len(manifest['source_hashes']),'selection_reason':manifest['selection_reason'],'full_t01_gate':'deferred to renewed final W10','full_t06_gate':'deferred to W12','stages':[]};h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():(out/'status.json').write_text(json.dumps(state,sort_keys=True,indent=2)+'\n')
def git(root,*args):return subprocess.check_output(['/usr/bin/git','-C',str(root),*args],text=True).strip()
def verify():
 assert git(repo,'rev-parse','HEAD')==manifest['source_commit']
 assert git(repo,'status','--porcelain','--untracked-files=all')==''
 for p,sha in manifest['source_hashes'].items():assert h(repo/p)==sha,p
save()
try:
 upstream=pathlib.Path('/root/mpk');url=git(upstream,'remote','get-url','origin');assert url in ['https://github.com/finitefield-org/mpk.git','git@github.com:finitefield-org/mpk.git']
 subprocess.run(['/usr/bin/git','-C',str(upstream),'fetch','origin','refs/heads/codex/w09-packed-pattern-proofs'],check=True)
 assert not repo.exists();subprocess.run(['/usr/bin/git','-C',str(upstream),'worktree','add','--detach',str(repo),manifest['source_commit']],check=True)
 verify();state['status']='running';save();env=os.environ.copy();env['CARGO_TARGET_DIR']=str(target);env['PATH']='/root/.cargo/bin:/usr/local/bin:/usr/bin:/bin';env['PYTHONDONTWRITEBYTECODE']='1'
 for p in manifest['jobs']:
  label=p['destination'];generated=out/'goldens'/label;generated.mkdir(parents=True);env_job=env.copy();env_job[p['variable']]=str(generated)
  state['stage']=label;t=time.monotonic();cmd=['/root/.cargo/bin/cargo','test','-p','mpk-vc','--test','csharp_practical_vc',p['selector'],'--','--nocapture','--test-threads=1']
  with (out/(label+'.log.txt')).open('wb') as log:
   process=subprocess.Popen(cmd,cwd=repo,env=env_job,stdout=log,stderr=subprocess.STDOUT);state['process_pid']=process.pid;save();code=process.wait()
  counts=re.findall(r'test result: ok\. (\d+) passed; 0 failed;', (out/(label+'.log.txt')).read_text());stage={'stage':label,'selector':p['selector'],'exit_code':code,'elapsed_seconds':time.monotonic()-t,'test_counts':counts,'log_sha256':h(out/(label+'.log.txt')),'generated_files':{str(x.relative_to(generated)):h(x) for x in generated.rglob('*') if x.is_file()}};state['stages'].append(stage);save();assert code==0 and counts==['1'],label;verify()
 state['status']='passed_selected_exact_public_source_linux_ordinary_owners'
except BaseException as e:state['status']='failed';state['error']=repr(e);raise
finally:save()
print(json.dumps(state),flush=True)
